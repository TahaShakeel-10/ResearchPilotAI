/**
 * ResearchPilotAI - Core Data Models and Types
 * Strict typing across all multi-agent stages, evidence engine, and prototypes.
 */

export type EvidenceStatus = 
  | 'VERIFIED_SOURCE'
  | 'DATA_DERIVED'
  | 'AI_INTERPRETATION'
  | 'HYPOTHESIS'
  | 'INSUFFICIENT_EVIDENCE';

export interface SourceCitation {
  id: string;
  title: string;
  authors: string[];
  year: number;
  source: string;
  urlOrDoi?: string;
  relevance: string;
  keyFinding: string;
  evidenceStatus: EvidenceStatus;
  isVerified: boolean;
}

export interface EvidenceClaim {
  id: string;
  claim: string;
  status: EvidenceStatus;
  sourceIds: string[];
  explanation: string;
  confidence: 'High' | 'Moderate' | 'Tentative' | 'Insufficient';
}

export interface ResearchPlan {
  refined_question: string;
  discipline: string;
  research_objectives: string[];
  sub_questions: string[];
  suggested_methodology: string;
  required_evidence: string[];
  data_requirements: string[];
}

export interface DescriptiveStat {
  mean: number;
  median: number;
  stdDev: number;
  min: number;
  max: number;
  count: number;
}

export interface RegressionModelResult {
  xVar: string;
  yVar: string;
  rSquared: number;
  slope: number;
  intercept: number;
  pValueApprox?: number;
  equation: string;
  interpretation: string;
}

export interface DataAnalysisResult {
  datasetName: string;
  datasetSize: number;
  rowCount: number;
  columnCount: number;
  columns: string[];
  numericalColumns: string[];
  categoricalColumns: string[];
  descriptiveStats: Record<string, DescriptiveStat>;
  missingValues: Record<string, number>;
  correlations?: {
    vars: string[];
    matrix: number[][];
  };
  regressionModel?: RegressionModelResult;
  groupComparison?: {
    groupByCol: string;
    targetCol: string;
    groups: Record<string, { count: number; mean: number }>;
  };
  keyStatistics: string[];
  limitations: string[];
  sampleRows: Record<string, any>[];
}

export interface ResearchGapAnalysis {
  establishedKnowledge: Array<{
    title: string;
    description: string;
    supportingSources: string[];
  }>;
  evidenceGaps: Array<{
    gap: string;
    whyItMatters: string;
    cautiousNote: string;
  }>;
  contradictions: Array<{
    topic: string;
    sideA: string;
    sideB: string;
    resolutionStatus: string;
  }>;
  methodologicalGaps: Array<{
    area: string;
    limitationInLiterature: string;
    suggestedApproach: string;
  }>;
  populationGeographicGaps: Array<{
    underrepresentedDomain: string;
    context: string;
  }>;
  potentialOpportunities: Array<{
    opportunity: string;
    feasibility: string;
  }>;
}

export interface ProposedHypothesis {
  id: string;
  hypothesis: string;
  rationale: string;
  supportingEvidence: string[];
  independentVariable: string;
  dependentVariable: string;
  suggestedMethodology: string;
  expectedRelationship: string;
  limitations: string[];
  statusLabel: 'PROPOSED HYPOTHESIS';
}

export interface InvestigationSynthesis {
  whatIsKnown: string;
  whatEvidenceFound: string;
  whatDataShows: string;
  patternsIdentified: string[];
  whatRemainsUncertain: string;
  whatResearchGapExists: string;
  whatHypothesisEmerges: string;
  whatShouldBeInvestigatedNext: string;
}

export interface MiniPaper {
  title: string;
  abstract: string;
  keywords: string[];
  sections: {
    introduction: string;
    researchProblem: string;
    researchQuestion: string;
    objectives: string[];
    literatureReview: string;
    researchGap: string;
    hypothesis: string;
    methodology: string;
    dataAndAnalysis: string;
    results: string;
    discussion: string;
    limitations: string;
    conclusion: string;
    futureResearch: string;
  };
  references: Array<{
    id: string;
    citationText: string;
    url?: string;
  }>;
}

export type PrototypeType = 
  | 'web-application'
  | 'dashboard'
  | 'prediction-system'
  | 'educational-tool'
  | 'visualization'
  | 'simulation'
  | 'workflow'
  | 'recommendation-system'
  | 'ai-assistant'
  | 'monitoring-system'
  | 'proof-of-concept';

export interface PrototypeSpecification {
  feasible: boolean;
  alternativeRoadmap?: string;
  problem: string;
  targetUsers: string;
  proposedSolution: string;
  prototypeType: PrototypeType;
  coreFeatures: string[];
  userJourney: string[];
  aiComponent: string;
  dataRequirements: string;
  systemArchitecture: string;
  technicalStack: string;
  specificationDetails: string;
  interactiveComponentId: string;
  disclaimer: 'RESEARCH PROTOTYPE — NOT A DEPLOYED PRODUCT';
}

export interface ResearchInvestigation {
  id: string;
  title: string;
  question: string;
  discipline: string;
  goal: string;
  hasDataset: boolean;
  rawDatasetCsv?: string;
  createdAt: string;
  plan: ResearchPlan;
  sources: SourceCitation[];
  evidenceClaims: EvidenceClaim[];
  dataAnalysis?: DataAnalysisResult;
  gaps: ResearchGapAnalysis;
  hypotheses: ProposedHypothesis[];
  synthesis: InvestigationSynthesis;
  paper: MiniPaper;
  prototype: PrototypeSpecification;
  isDemo?: boolean;
}

export type ActiveTab = 
  | 'dashboard'
  | 'investigation'
  | 'evidence'
  | 'data-analysis'
  | 'research-gaps'
  | 'hypotheses'
  | 'mini-paper'
  | 'prototype'
  | 'portfolio'
  | 'visual-map';

export type PipelineStage = 
  | 'question'
  | 'plan'
  | 'discover'
  | 'analyze'
  | 'gap'
  | 'hypothesis'
  | 'paper'
  | 'prototype';
