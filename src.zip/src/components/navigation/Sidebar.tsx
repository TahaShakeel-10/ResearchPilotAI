/**
 * ResearchPilotAI - Primary Sidebar Navigation (Section 16)
 * Brand logo, multi-agent view switchers, demo switchers, and AI Transparency modal toggle.
 */

import React from 'react';
import { ActiveTab } from '../../types/research';
import { 
  Compass, 
  PlusCircle, 
  FolderGit2, 
  ShieldCheck, 
  BarChart3, 
  Search, 
  FlaskConical, 
  FileText, 
  Rocket, 
  Briefcase, 
  Map, 
  Settings, 
  Info, 
  Scale,
  Sparkles,
  ChevronRight
} from 'lucide-react';

interface Props {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  onNewInvestigation: () => void;
  onOpenTransparency: () => void;
  investigationTitle: string;
}

export const Sidebar: React.FC<Props> = ({
  activeTab,
  onSelectTab,
  onNewInvestigation,
  onOpenTransparency,
  investigationTitle,
}) => {
  const navItems: Array<{
    id: ActiveTab;
    label: string;
    icon: any;
    badge?: string;
  }> = [
    { id: 'dashboard', label: 'Dashboard', icon: Compass },
    { id: 'investigation', label: 'Investigation Pipeline', icon: Sparkles },
    { id: 'visual-map', label: 'Visual Research Map', icon: Map, badge: 'Interactive' },
    { id: 'evidence', label: 'Evidence & Literature', icon: ShieldCheck },
    { id: 'data-analysis', label: 'Data Analysis', icon: BarChart3 },
    { id: 'research-gaps', label: 'Research Gaps', icon: Search, badge: 'Signature' },
    { id: 'hypotheses', label: 'Hypotheses', icon: FlaskConical },
    { id: 'mini-paper', label: 'Mini Paper', icon: FileText },
    { id: 'prototype', label: 'Prototype Playground', icon: Rocket, badge: 'Innovation' },
    { id: 'portfolio', label: 'Research Portfolio', icon: Briefcase },
  ];

  return (
    <aside className="w-64 bg-slate-950 border-r border-slate-800 flex flex-col justify-between shrink-0 select-none min-h-screen">
      {/* Brand & Investigation Scope */}
      <div className="p-5 space-y-4">
        {/* Logo */}
        <div 
          onClick={() => onSelectTab('dashboard')}
          className="flex items-center gap-3 cursor-pointer group"
        >
          <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/40 flex items-center justify-center text-emerald-400 group-hover:scale-105 transition-transform">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h1 className="font-extrabold text-sm text-slate-100 tracking-tight flex items-center gap-1.5">
              <span>ResearchPilot</span>
              <span className="text-emerald-400 font-mono text-xs">AI</span>
            </h1>
            <span className="text-[10px] text-slate-400 block font-normal">Question to Innovation</span>
          </div>
        </div>

        {/* Primary CTA: New Investigation */}
        <button
          onClick={onNewInvestigation}
          className="w-full py-2.5 px-3.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-2 transition-all shadow-md hover:shadow-emerald-950/50 cursor-pointer"
        >
          <PlusCircle className="w-4 h-4" />
          <span>New Investigation</span>
        </button>

        {/* Active Investigation Context Tag */}
        <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 text-[11px] space-y-1">
          <span className="font-mono text-[9px] uppercase tracking-wider text-slate-400 block">
            Current Investigation:
          </span>
          <p className="font-medium text-slate-200 line-clamp-2 leading-tight">
            {investigationTitle}
          </p>
        </div>
      </div>

      {/* Navigation List */}
      <nav className="px-3 flex-1 overflow-y-auto space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                isActive
                  ? 'bg-emerald-500/15 text-emerald-300 font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <div className="flex items-center gap-2.5 truncate">
                <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-emerald-400' : 'text-slate-400'}`} />
                <span className="truncate">{item.label}</span>
              </div>
              {item.badge && (
                <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700/60 shrink-0">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Footer Controls: AI Transparency, About, Settings */}
      <div className="p-4 border-t border-slate-800/80 space-y-2 text-xs">
        <button
          onClick={onOpenTransparency}
          className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-slate-400 hover:text-emerald-300 hover:bg-slate-900 transition-colors cursor-pointer text-left"
        >
          <Scale className="w-4 h-4 text-emerald-400 shrink-0" />
          <span className="truncate">AI Transparency Charter</span>
        </button>

        <div className="pt-2 border-t border-slate-800/50 flex items-center justify-between text-[11px] text-slate-400 font-mono">
          <span>v1.0.0-hackathon</span>
          <span className="text-emerald-400">Gemini Powered</span>
        </div>
      </div>
    </aside>
  );
};
