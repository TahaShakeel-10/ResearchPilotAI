/**
 * ResearchPilotAI - Dynamic Research Prototype Engine
 * Renders an interactive functional prototype for any custom user research investigation.
 * Clearly labeled as a research prototype.
 */

import React, { useState } from 'react';
import { ResearchInvestigation } from '../../types/research';
import { ShieldAlert, Sliders, Activity, Sparkles, CheckCircle2, TrendingUp, Layers } from 'lucide-react';

interface Props {
  investigation: ResearchInvestigation;
}

export const DynamicScenarioPrototype: React.FC<Props> = ({ investigation }) => {
  const hyp = investigation.hypotheses[0];
  const ivName = hyp?.independentVariable || 'Primary Input Parameter';
  const dvName = hyp?.dependentVariable || 'Simulated Outcome Metric';

  // Default interactive parameters
  const [ivValue, setIvValue] = useState<number>(50);
  const [sensitivityFactor, setSensitivityFactor] = useState<number>(1.2);
  const [secondaryControl, setSecondaryControl] = useState<boolean>(true);

  // If data analysis model exists, use its slope & intercept; otherwise calibrated heuristic
  const slope = investigation.dataAnalysis?.regressionModel?.slope ?? 0.65;
  const intercept = investigation.dataAnalysis?.regressionModel?.intercept ?? 20;

  const calculatedDv = Number((intercept + slope * (ivValue * sensitivityFactor) * (secondaryControl ? 1.0 : 0.85)).toFixed(2));

  return (
    <div className="space-y-6">
      {/* Required Prototype Banner */}
      <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-4 flex items-start gap-3">
        <ShieldAlert className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
        <div>
          <span className="text-xs font-semibold uppercase tracking-wider text-amber-500">
            RESEARCH PROTOTYPE — NOT A DEPLOYED PRODUCT
          </span>
          <p className="text-xs text-slate-400 mt-1">
            {investigation.prototype.disclaimer}. Generated to demonstrate technical feasibility and translation of the research findings into an operational software workflow.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Controls Column */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="font-semibold text-slate-100 flex items-center gap-2 text-sm">
              <Sliders className="w-4 h-4 text-emerald-400" />
              Dynamic Investigation Variables
            </h3>
            <span className="text-xs text-slate-400">Model Inputs</span>
          </div>

          {/* Primary IV Slider */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300 truncate max-w-[180px]" title={ivName}>{ivName}</span>
              <span className="font-mono text-emerald-400 font-semibold">{ivValue}</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              step="1"
              value={ivValue}
              onChange={(e) => setIvValue(parseFloat(e.target.value))}
              aria-label={ivName}
              className="w-full accent-emerald-500 bg-slate-800 h-2 rounded cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400 font-mono">
              <span>0 (Min)</span>
              <span>50</span>
              <span>100 (Max)</span>
            </div>
          </div>

          {/* Sensitivity Modifier */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300">Intervention Sensitivity</span>
              <span className="font-mono text-cyan-400 font-semibold">{sensitivityFactor}x</span>
            </div>
            <input
              type="range"
              min="0.5"
              max="2.0"
              step="0.1"
              value={sensitivityFactor}
              onChange={(e) => setSensitivityFactor(parseFloat(e.target.value))}
              aria-label="Intervention Sensitivity multiplier"
              className="w-full accent-cyan-500 bg-slate-800 h-2 rounded cursor-pointer"
            />
          </div>

          {/* Moderator Checkbox */}
          <div className="pt-2 border-t border-slate-800">
            <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={secondaryControl}
                onChange={(e) => setSecondaryControl(e.target.checked)}
                className="rounded accent-emerald-500"
              />
              Enable High-Fidelity Moderator Coupling
            </label>
          </div>

          <div className="p-3 bg-slate-800/40 rounded-lg border border-slate-800 text-[11px] text-slate-400 space-y-1">
            <span className="font-semibold text-slate-300 block">Proposed System Solution:</span>
            <p>{investigation.prototype.proposedSolution}</p>
          </div>
        </div>

        {/* Dynamic Simulation Output */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
            <span className="text-xs text-slate-400 block mb-1">Simulated Dependent Outcome ({dvName})</span>
            <div className="flex items-baseline gap-3">
              <span className="text-4xl font-extrabold font-mono text-emerald-400">
                {calculatedDv}
              </span>
              <span className="text-xs text-slate-400 font-mono">
                {investigation.dataAnalysis?.regressionModel ? `Model: ${investigation.dataAnalysis.regressionModel.equation}` : 'Simulation model'}
              </span>
            </div>

            <div className="mt-4 pt-4 border-t border-slate-800 grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-3 bg-slate-800/50 rounded-lg">
                <span className="text-xs font-semibold text-slate-200 block mb-1">Target Users</span>
                <p className="text-xs text-slate-400">{investigation.prototype.targetUsers}</p>
              </div>

              <div className="p-3 bg-slate-800/50 rounded-lg">
                <span className="text-xs font-semibold text-slate-200 block mb-1">AI / Algorithmic Core</span>
                <p className="text-xs text-slate-400">{investigation.prototype.aiComponent}</p>
              </div>
            </div>

            {/* Core Features list */}
            <div className="mt-4 pt-4 border-t border-slate-800">
              <span className="text-xs font-semibold text-slate-200 block mb-2">Operational Features Specified:</span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {investigation.prototype.coreFeatures.map((feat, i) => (
                  <div key={i} className="flex items-center gap-2 text-xs text-slate-300">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>{feat}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
