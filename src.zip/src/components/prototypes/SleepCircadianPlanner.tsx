/**
 * ResearchPilotAI - Prototype 1: Sleep Circadian Planner
 * Interactive research-to-prototype application derived from Sleep & GPA investigation.
 * Clearly labeled as a research prototype.
 */

import React, { useState } from 'react';
import { Moon, Sun, Clock, BookOpen, AlertTriangle, Sparkles, Activity, ShieldAlert, Award } from 'lucide-react';

export const SleepCircadianPlanner: React.FC = () => {
  const [sleepHours, setSleepHours] = useState<number>(7.2);
  const [bedtimeVarianceMin, setBedtimeVarianceMin] = useState<number>(30);
  const [studyHours, setStudyHours] = useState<number>(4.0);
  const [screenTime, setScreenTime] = useState<number>(3.0);
  const [chronotype, setChronotype] = useState<'EarlyBird' | 'Intermediate' | 'NightOwl'>('Intermediate');

  // Mathematical regression formula derived from cohort: GPA = 0.383 * SleepHours + 0.835
  // Penalized by high bedtime variance and screen time
  const baseGpa = 0.383 * sleepHours + 0.835;
  const consistencyPenalty = (bedtimeVarianceMin / 60) * 0.18;
  const screenPenalty = screenTime > 3 ? (screenTime - 3) * 0.08 : 0;
  const projectedGpa = Math.max(1.8, Math.min(4.0, Number((baseGpa - consistencyPenalty - screenPenalty).toFixed(2))));

  // Circadian Alertness Curve points throughout the day (0:00 to 23:00)
  const shiftHours = chronotype === 'EarlyBird' ? -2 : chronotype === 'NightOwl' ? 3 : 0;
  const hours = Array.from({ length: 24 }, (_, i) => i);
  const alertnessPoints = hours.map(h => {
    const adjH = (h - shiftHours + 24) % 24;
    // Standard circadian curve: dip at 3-5 AM, peak at 10-12 AM, post-lunch dip at 2-3 PM, secondary peak at 6-8 PM
    let val = 50;
    if (adjH >= 2 && adjH <= 6) val = 15;
    else if (adjH > 6 && adjH <= 9) val = 60;
    else if (adjH > 9 && adjH <= 13) val = 92;
    else if (adjH > 13 && adjH <= 16) val = 65;
    else if (adjH > 16 && adjH <= 21) val = 88;
    else val = 40;

    // Sleep deficit drag
    const deficitDrag = Math.max(0, (7.5 - sleepHours) * 8);
    return Math.max(10, val - deficitDrag);
  });

  return (
    <div className="space-y-6">
      {/* Required Prototype Banner */}
      <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-4 flex items-start gap-3">
        <ShieldAlert className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
        <div>
          <span className="text-xs font-semibold uppercase tracking-wider text-amber-500">
            RESEARCH PROTOTYPE — NOT A DEPLOYED PRODUCT
          </span>
          <p className="text-xs text-slate-400 mt-1">
            This interactive tool demonstrates translation of regression findings into an applied simulation. It does not replace individualized clinical sleep diagnosis or academic advising.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Controls Column */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="font-semibold text-slate-100 flex items-center gap-2 text-sm">
              <Clock className="w-4 h-4 text-emerald-400" />
              Sleep & Schedule Parameters
            </h3>
            <span className="text-xs text-slate-400">Interactive Inputs</span>
          </div>

          {/* Sleep Hours Slider */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300">Average Sleep Duration</span>
              <span className="font-mono text-emerald-400 font-semibold">{sleepHours} hrs/night</span>
            </div>
            <input
              type="range"
              min="4.0"
              max="9.5"
              step="0.1"
              value={sleepHours}
              onChange={(e) => setSleepHours(parseFloat(e.target.value))}
              aria-label="Average Sleep Duration"
              className="w-full accent-emerald-500 bg-slate-800 h-2 rounded cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>4.0h (Severe deficit)</span>
              <span>7.5h (Optimal)</span>
              <span>9.5h</span>
            </div>
          </div>

          {/* Bedtime Variance Slider */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300">Bedtime Variance (SRI)</span>
              <span className="font-mono text-cyan-400 font-semibold">±{bedtimeVarianceMin} mins</span>
            </div>
            <input
              type="range"
              min="10"
              max="150"
              step="5"
              value={bedtimeVarianceMin}
              onChange={(e) => setBedtimeVarianceMin(parseInt(e.target.value))}
              aria-label="Bedtime Variance in minutes"
              className="w-full accent-cyan-500 bg-slate-800 h-2 rounded cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>±10m (Highly consistent)</span>
              <span>±60m</span>
              <span>±150m (Erratic)</span>
            </div>
          </div>

          {/* Study Hours */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300">Daily Study Hours</span>
              <span className="font-mono text-indigo-400 font-semibold">{studyHours} hrs/day</span>
            </div>
            <input
              type="range"
              min="1.0"
              max="8.0"
              step="0.5"
              value={studyHours}
              onChange={(e) => setStudyHours(parseFloat(e.target.value))}
              aria-label="Daily Study Hours"
              className="w-full accent-indigo-500 bg-slate-800 h-2 rounded cursor-pointer"
            />
          </div>

          {/* Evening Screen Time */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300">Pre-Bed Screen Time</span>
              <span className="font-mono text-amber-400 font-semibold">{screenTime} hrs</span>
            </div>
            <input
              type="range"
              min="0.5"
              max="6.0"
              step="0.5"
              value={screenTime}
              onChange={(e) => setScreenTime(parseFloat(e.target.value))}
              aria-label="Pre-Bed Screen Time"
              className="w-full accent-amber-500 bg-slate-800 h-2 rounded cursor-pointer"
            />
          </div>

          {/* Chronotype Selector */}
          <div className="space-y-2">
            <label className="text-xs text-slate-300 block">Circadian Chronotype</label>
            <div className="grid grid-cols-3 gap-2">
              {(['EarlyBird', 'Intermediate', 'NightOwl'] as const).map(type => (
                <button
                  key={type}
                  onClick={() => setChronotype(type)}
                  className={`py-2 px-2 text-xs rounded-lg border text-center transition-all ${
                    chronotype === type
                      ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300 font-medium'
                      : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {type === 'EarlyBird' ? 'Early Larks' : type === 'Intermediate' ? 'Intermediate' : 'Night Owls'}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Predictive Outcomes & Alertness Visualizer */}
        <div className="lg:col-span-2 space-y-6">
          {/* Top Key Performance Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
              <span className="text-xs text-slate-400 block mb-1">Projected Semester GPA</span>
              <div className="flex items-baseline gap-2">
                <span className={`text-3xl font-bold font-mono ${projectedGpa >= 3.5 ? 'text-emerald-400' : projectedGpa >= 3.0 ? 'text-cyan-400' : 'text-amber-400'}`}>
                  {projectedGpa.toFixed(2)}
                </span>
                <span className="text-xs text-slate-400">/ 4.00</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-2">
                Derived from regression weights: GPA = 0.383 × Sleep + 0.835 minus regularity penalty.
              </p>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
              <span className="text-xs text-slate-400 block mb-1">Circadian Regularity</span>
              <div className="flex items-baseline gap-2">
                <span className="text-2xl font-bold font-mono text-cyan-400">
                  {bedtimeVarianceMin <= 35 ? 'Optimal' : bedtimeVarianceMin <= 75 ? 'Moderate' : 'Erratic'}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-2">
                Variance ±{bedtimeVarianceMin}m vs Okano et al. 45m threshold.
              </p>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
              <span className="text-xs text-slate-400 block mb-1">Cognitive Alertness Deficit</span>
              <div className="flex items-baseline gap-2">
                <span className={`text-2xl font-bold font-mono ${sleepHours >= 7.0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {sleepHours >= 7.5 ? '0.0h (Nil)' : `-${(7.5 - sleepHours).toFixed(1)}h / night`}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-2">
                Cumulative sleep debt reduces procedural recall speed.
              </p>
            </div>
          </div>

          {/* Diurnal Cognitive Alertness Chart */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h4 className="font-semibold text-slate-100 text-sm flex items-center gap-2">
                  <Activity className="w-4 h-4 text-emerald-400" />
                  Simulated 24-Hour Cognitive Alertness Curve
                </h4>
                <p className="text-xs text-slate-400">
                  Oscillations based on circadian phase and adjusted for current sleep deficit
                </p>
              </div>
              <div className="text-xs text-slate-400 flex items-center gap-3">
                <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span> Alertness %</span>
                <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-indigo-500"></span> Recommended Study Block</span>
              </div>
            </div>

            {/* SVG Visualizer */}
            <div className="h-44 w-full relative">
              <svg className="w-full h-full overflow-visible" viewBox="0 0 500 120" preserveAspectRatio="none">
                {/* Horizontal reference lines */}
                <line x1="0" y1="20" x2="500" y2="20" stroke="#334155" strokeDasharray="3 3" strokeWidth="0.8" />
                <line x1="0" y1="60" x2="500" y2="60" stroke="#334155" strokeDasharray="3 3" strokeWidth="0.8" />
                <line x1="0" y1="100" x2="500" y2="100" stroke="#334155" strokeDasharray="3 3" strokeWidth="0.8" />

                {/* Shaded Peak Study Windows */}
                {chronotype === 'EarlyBird' && (
                  <rect x="145" y="10" width="80" height="90" fill="#6366f1" fillOpacity="0.15" rx="4" />
                )}
                {chronotype === 'Intermediate' && (
                  <rect x="200" y="10" width="80" height="90" fill="#6366f1" fillOpacity="0.15" rx="4" />
                )}
                {chronotype === 'NightOwl' && (
                  <rect x="270" y="10" width="90" height="90" fill="#6366f1" fillOpacity="0.15" rx="4" />
                )}

                {/* Alertness Curve */}
                <path
                  d={`M ${alertnessPoints.map((val, idx) => `${(idx / 23) * 500},${110 - (val / 100) * 90}`).join(' L ')}`}
                  fill="none"
                  stroke="#10b981"
                  strokeWidth="2.5"
                />

                {/* Data Points */}
                {alertnessPoints.map((val, idx) => {
                  if (idx % 2 === 0) {
                    const cx = (idx / 23) * 500;
                    const cy = 110 - (val / 100) * 90;
                    return (
                      <circle key={idx} cx={cx} cy={cy} r="3" fill="#10b981" />
                    );
                  }
                  return null;
                })}
              </svg>

              {/* Time Labels */}
              <div className="flex justify-between text-[10px] text-slate-400 mt-2 font-mono">
                <span>00:00</span>
                <span>04:00</span>
                <span>08:00</span>
                <span>12:00</span>
                <span>16:00</span>
                <span>20:00</span>
                <span>23:59</span>
              </div>
            </div>

            {/* Smart Study Recommendations */}
            <div className="mt-6 pt-4 border-t border-slate-800 grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-3 bg-slate-800/60 rounded-lg">
                <span className="text-xs font-semibold text-indigo-300 flex items-center gap-1.5 mb-1">
                  <BookOpen className="w-3.5 h-3.5" /> Optimal Deep-Work Window
                </span>
                <p className="text-xs text-slate-300">
                  {chronotype === 'EarlyBird'
                    ? '08:30 - 11:30 AM (Peak prefrontal cortex alertness)'
                    : chronotype === 'Intermediate'
                    ? '10:00 AM - 1:00 PM (Optimal working memory capacity)'
                    : '4:00 PM - 8:30 PM (Aligned with evening circadian peak)'}
                </p>
              </div>

              <div className="p-3 bg-slate-800/60 rounded-lg">
                <span className="text-xs font-semibold text-amber-300 flex items-center gap-1.5 mb-1">
                  <Moon className="w-3.5 h-3.5" /> Evening Sleep Hygiene Directive
                </span>
                <p className="text-xs text-slate-300">
                  {screenTime > 3.0
                    ? `Reduce screen exposure by 90 min before bed; current screen time adds ~${(screenPenalty).toFixed(2)} penalty to GPA.`
                    : 'Current evening screen time is well-controlled; maintain consistent wake alarm.'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
