/**
 * ResearchPilotAI - Prototype 2: Urban HydroPredict AI
 * Interactive Catchment Inundation & Early-Warning Simulation Prototype.
 * Clearly labeled as a research prototype.
 */

import React, { useState } from 'react';
import { CloudRain, Droplets, ShieldAlert, AlertTriangle, Layers, Activity, RefreshCw } from 'lucide-react';

export const UrbanHydroPredictor: React.FC = () => {
  const [rainfallMm, setRainfallMm] = useState<number>(75);
  const [imperviousPct, setImperviousPct] = useState<number>(70);
  const [drainageCapacity, setDrainageCapacity] = useState<number>(500);
  const [soilMoisturePct, setSoilMoisturePct] = useState<number>(75);
  const [elevationM, setElevationM] = useState<number>(15);
  const [hasRetentionBasin, setHasRetentionBasin] = useState<boolean>(false);
  const [hasPermeablePavement, setHasPermeablePavement] = useState<boolean>(false);

  // Hydrological calculations
  const effectiveImpervious = hasPermeablePavement ? Math.max(20, imperviousPct - 25) : imperviousPct;
  const effectiveDrainage = hasRetentionBasin ? drainageCapacity + 250 : drainageCapacity;

  // Runoff volume calculation (m3/hr per standard hectare catchment)
  // Q = C * I * A (Rational Method)
  // C = runoff coefficient based on impervious ground and soil moisture
  const cCoeff = Math.min(0.95, (effectiveImpervious / 100) * 0.75 + (soilMoisturePct / 100) * 0.25);
  const catchmentAreaHa = 10; // 10 hectares
  const rawRunoffM3 = (cCoeff * rainfallMm * catchmentAreaHa * 10); // in m3/hr

  // Culvert choke ratio
  const chokeRatio = Number((rawRunoffM3 / effectiveDrainage).toFixed(2));
  
  // Flood Risk Index (0 - 10)
  // Calibrated with regression: FloodRiskScore = 0.089 * Rainfall - 0.009, adjusted for choke and elevation
  const elevationFactor = Math.max(0.6, 1.4 - (elevationM / 50));
  let calculatedRisk = (0.089 * rainfallMm) * (effectiveImpervious / 60) * elevationFactor;
  if (chokeRatio > 1.0) {
    calculatedRisk += (chokeRatio - 1.0) * 2.5;
  }
  const floodRiskScore = Math.max(0.5, Math.min(10.0, Number(calculatedRisk.toFixed(1))));

  const riskTier = floodRiskScore >= 8.0 
    ? { label: 'CRITICAL HAZARD', color: 'text-rose-400', bg: 'bg-rose-500/10', border: 'border-rose-500/30' }
    : floodRiskScore >= 6.0 
    ? { label: 'SEVERE RISK', color: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/30' }
    : floodRiskScore >= 3.5 
    ? { label: 'ELEVATED VULNERABILITY', color: 'text-yellow-400', bg: 'bg-yellow-500/10', border: 'border-yellow-500/30' }
    : { label: 'NOMINAL / LOW RISK', color: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/30' };

  return (
    <div className="space-y-6">
      {/* Required Prototype Banner */}
      <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-4 flex items-start gap-3">
        <ShieldAlert className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
        <div>
          <span className="text-xs font-semibold uppercase tracking-wider text-amber-500">
            RESEARCH PROTOTYPE — NOT A DEPLOYED PRODUCT
          </span>
          <p className="text-xs text-slate-400 mt-1">
            Hydro-topographical simulation tool for scenario analysis based on micro-catchment regression formulas. Not an officially certified municipal life-safety evacuation system.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Scenario Controls */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="font-semibold text-slate-100 flex items-center gap-2 text-sm">
              <CloudRain className="w-4 h-4 text-cyan-400" />
              Meteorological & Catchment Inputs
            </h3>
            <span className="text-xs text-slate-400">Telemetry</span>
          </div>

          {/* Rainfall Slider */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300">Forecasted Rainfall Rate</span>
              <span className="font-mono text-cyan-400 font-semibold">{rainfallMm} mm/hr</span>
            </div>
            <input
              type="range"
              min="10"
              max="140"
              step="5"
              value={rainfallMm}
              onChange={(e) => setRainfallMm(parseFloat(e.target.value))}
              aria-label="Forecasted Rainfall Rate in mm/hr"
              className="w-full accent-cyan-500 bg-slate-800 h-2 rounded cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>10mm (Drizzle)</span>
              <span>60mm (Heavy Storm)</span>
              <span>140mm (Cloudburst)</span>
            </div>
          </div>

          {/* Impervious Ground % */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300">Impervious Surface Coverage</span>
              <span className="font-mono text-indigo-400 font-semibold">{imperviousPct}%</span>
            </div>
            <input
              type="range"
              min="15"
              max="95"
              step="5"
              value={imperviousPct}
              onChange={(e) => setImperviousPct(parseInt(e.target.value))}
              aria-label="Impervious Surface Coverage percentage"
              className="w-full accent-indigo-500 bg-slate-800 h-2 rounded cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>15% (Parks/Rural)</span>
              <span>55% (Suburban)</span>
              <span>95% (Dense Downtown)</span>
            </div>
          </div>

          {/* Soil Moisture % */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300">Antecedent Soil Saturation</span>
              <span className="font-mono text-emerald-400 font-semibold">{soilMoisturePct}%</span>
            </div>
            <input
              type="range"
              min="20"
              max="100"
              step="5"
              value={soilMoisturePct}
              onChange={(e) => setSoilMoisturePct(parseInt(e.target.value))}
              aria-label="Antecedent Soil Saturation percentage"
              className="w-full accent-emerald-500 bg-slate-800 h-2 rounded cursor-pointer"
            />
          </div>

          {/* Drainage Sewer Capacity */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300">Conduit Sewer Capacity</span>
              <span className="font-mono text-sky-400 font-semibold">{drainageCapacity} m³/hr</span>
            </div>
            <input
              type="range"
              min="200"
              max="900"
              step="50"
              value={drainageCapacity}
              onChange={(e) => setDrainageCapacity(parseInt(e.target.value))}
              aria-label="Conduit Sewer Capacity in m3/hr"
              className="w-full accent-sky-500 bg-slate-800 h-2 rounded cursor-pointer"
            />
          </div>

          {/* Elevation */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300">Catchment Elevation</span>
              <span className="font-mono text-amber-400 font-semibold">{elevationM} m MSL</span>
            </div>
            <input
              type="range"
              min="5"
              max="60"
              step="5"
              value={elevationM}
              onChange={(e) => setElevationM(parseInt(e.target.value))}
              aria-label="Catchment Elevation in meters"
              className="w-full accent-amber-500 bg-slate-800 h-2 rounded cursor-pointer"
            />
          </div>

          {/* Mitigation Interventions */}
          <div className="pt-2 border-t border-slate-800 space-y-2">
            <label className="text-xs text-slate-300 font-medium block">Test Mitigation Countermeasures</label>
            <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={hasRetentionBasin}
                onChange={(e) => setHasRetentionBasin(e.target.checked)}
                className="rounded accent-emerald-500"
              />
              Deploy Auxiliary Stormwater Retention Basin (+250 m³/hr)
            </label>
            <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={hasPermeablePavement}
                onChange={(e) => setHasPermeablePavement(e.target.checked)}
                className="rounded accent-cyan-500"
              />
              Retrofit Permeable Paver Infiltration (-25% Impervious)
            </label>
          </div>
        </div>

        {/* Dynamic Simulation Output */}
        <div className="lg:col-span-2 space-y-6">
          {/* Risk Severity Status Banner */}
          <div className={`${riskTier.bg} border ${riskTier.border} rounded-xl p-5 flex flex-col sm:flex-row items-center justify-between gap-4`}>
            <div>
              <span className="text-xs text-slate-400 block mb-1">Catchment Inundation Risk Score</span>
              <div className="flex items-baseline gap-3">
                <span className={`text-4xl font-extrabold font-mono ${riskTier.color}`}>
                  {floodRiskScore.toFixed(1)}
                </span>
                <span className="text-sm font-semibold tracking-wide uppercase text-slate-200">
                  {riskTier.label}
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1">
                Regression formulation adjusted for hydraulic capacity breach and elevation gradient.
              </p>
            </div>

            <div className="text-right sm:border-l border-slate-700/50 sm:pl-6 w-full sm:w-auto">
              <span className="text-xs text-slate-400 block">Culvert Choke Ratio</span>
              <span className={`text-2xl font-bold font-mono ${chokeRatio > 1.0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                {chokeRatio}x
              </span>
              <span className="text-[11px] block text-slate-400 mt-0.5">
                {chokeRatio > 1.0 ? 'DRAINAGE OVERLOADED' : 'CAPACITY SUFFICIENT'}
              </span>
            </div>
          </div>

          {/* Key Simulation Gauges */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
              <span className="text-xs text-slate-400 block mb-1">Generated Surface Runoff</span>
              <span className="text-2xl font-bold font-mono text-cyan-400">
                {rawRunoffM3.toFixed(0)} m³/hr
              </span>
              <div className="w-full bg-slate-800 h-1.5 rounded-full mt-3 overflow-hidden">
                <div
                  className="bg-cyan-500 h-full transition-all duration-300"
                  style={{ width: `${Math.min(100, (rawRunoffM3 / 1000) * 100)}%` }}
                />
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
              <span className="text-xs text-slate-400 block mb-1">Effective Drainage Conduit</span>
              <span className="text-2xl font-bold font-mono text-indigo-400">
                {effectiveDrainage} m³/hr
              </span>
              <span className="text-[11px] text-slate-400 block mt-2">
                {hasRetentionBasin ? 'Includes +250 m³ auxiliary basin' : 'Standard municipal piping'}
              </span>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
              <span className="text-xs text-slate-400 block mb-1">Runoff Coefficient (C)</span>
              <span className="text-2xl font-bold font-mono text-amber-400">
                {cCoeff.toFixed(2)}
              </span>
              <span className="text-[11px] text-slate-400 block mt-2">
                Effective impervious fraction: {effectiveImpervious}%
              </span>
            </div>
          </div>

          {/* Micro-Catchment Spatial Cross-Section Visualizer */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
            <div className="flex items-center justify-between mb-4">
              <h4 className="font-semibold text-slate-100 text-sm flex items-center gap-2">
                <Layers className="w-4 h-4 text-cyan-400" />
                Cross-Section Hydraulic Inundation Simulation
              </h4>
              <span className="text-xs text-slate-400 font-mono">10 Hectare Urban Cell</span>
            </div>

            <div className="h-44 w-full bg-slate-950/70 border border-slate-800 rounded-lg p-3 relative overflow-hidden flex flex-col justify-end">
              {/* Rain Particle Visualization */}
              <div className="absolute inset-0 flex justify-around opacity-30 pointer-events-none">
                {Array.from({ length: 15 }).map((_, i) => (
                  <div
                    key={i}
                    className="w-0.5 bg-cyan-400 animate-pulse"
                    style={{
                      height: `${(rainfallMm / 140) * 80}%`,
                      animationDuration: `${0.4 + (i % 3) * 0.2}s`,
                    }}
                  />
                ))}
              </div>

              {/* Water Pooling Layer */}
              <div
                className="w-full transition-all duration-500 rounded bg-gradient-to-t from-cyan-600/60 to-cyan-400/20 border-t border-cyan-400/50 flex items-center justify-center"
                style={{ height: `${Math.min(90, (floodRiskScore / 10) * 85)}%` }}
              >
                {floodRiskScore > 4.0 && (
                  <span className="text-xs font-mono font-bold text-cyan-200 tracking-wider">
                    SURFACE WATER DEPTH: {(floodRiskScore * 5.2).toFixed(0)} cm
                  </span>
                )}
              </div>

              {/* Ground Cross Section */}
              <div className="h-6 w-full bg-slate-800 border-t border-slate-700 flex justify-between items-center px-4 text-[10px] text-slate-400 font-mono z-10">
                <span>Catchment Culvert Intake</span>
                <span>Soil Infiltration Zone ({soilMoisturePct}% Sat)</span>
                <span>Elev: {elevationM}m MSL</span>
              </div>
            </div>

            {/* Tactical Emergency Dispatch Directives */}
            <div className="mt-4 pt-3 border-t border-slate-800 flex items-start gap-3 text-xs text-slate-300">
              <AlertTriangle className={`w-4 h-4 shrink-0 mt-0.5 ${riskTier.color}`} />
              <div>
                <strong className="text-slate-100">Municipal Action Recommendation: </strong>
                {floodRiskScore >= 8.0 ? (
                  <span>Initiate immediate underpass traffic diversions and deploy auxiliary diesel pumps at lower conduit junctions.</span>
                ) : floodRiskScore >= 5.5 ? (
                  <span>Issue yellow localized street-ponding advisory for low-elevation transit arteries; stage emergency crews.</span>
                ) : (
                  <span>Standard stormwater intake operations; no evacuation or conduit diversion required.</span>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
