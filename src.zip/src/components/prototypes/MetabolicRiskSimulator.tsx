/**
 * ResearchPilotAI - Prototype 3: Metabolic Sentinel Risk Factor Simulator
 * Interactive biostatistical lifestyle intervention prototype.
 * Clearly labeled as a research prototype.
 */

import React, { useState } from 'react';
import { HeartPulse, Activity, Flame, ShieldAlert, Award, TrendingDown, ArrowRight } from 'lucide-react';

export const MetabolicRiskSimulator: React.FC = () => {
  const [age, setAge] = useState<number>(48);
  const [bmi, setBmi] = useState<number>(29.5);
  const [physicalActMin, setPhysicalActMin] = useState<number>(25);
  const [fastingGlucose, setFastingGlucose] = useState<number>(112);
  const [systolicBp, setSystolicBp] = useState<number>(132);

  // Proposed lifestyle intervention plan testing:
  const [targetActivityAdd, setTargetActivityAdd] = useState<number>(20);
  const [targetBmiLoss, setTargetBmiLoss] = useState<number>(1.5);

  // Baseline Risk Score formula derived from cohort regression and ADA clinical weights:
  // Base Risk = -0.113 * Activity + 8.94 + BMI adjustment + Glucose/BP adjustments
  const baseFromAct = -0.113 * physicalActMin + 8.94;
  const bmiFactor = (bmi - 22) * 0.15;
  const glucoseFactor = fastingGlucose > 100 ? (fastingGlucose - 100) * 0.04 : 0;
  const bpFactor = systolicBp > 120 ? (systolicBp - 120) * 0.03 : 0;

  const currentRiskScore = Math.max(0.5, Math.min(10.0, Number((baseFromAct + bmiFactor + glucoseFactor + bpFactor).toFixed(1))));

  // Post-Intervention Simulated Risk Score:
  const postActivity = physicalActMin + targetActivityAdd;
  const postBmi = Math.max(18.5, bmi - targetBmiLoss);
  const postFromAct = -0.113 * postActivity + 8.94;
  const postBmiFactor = (postBmi - 22) * 0.15;
  const postGlucoseFactor = fastingGlucose > 100 ? Math.max(0, (fastingGlucose - 100 - targetActivityAdd * 0.25) * 0.04) : 0;
  const postBpFactor = systolicBp > 120 ? Math.max(0, (systolicBp - 120 - targetActivityAdd * 0.15) * 0.03) : 0;

  const simulatedRiskScore = Math.max(0.5, Math.min(10.0, Number((postFromAct + postBmiFactor + postGlucoseFactor + postBpFactor).toFixed(1))));
  const riskDelta = Number((currentRiskScore - simulatedRiskScore).toFixed(1));

  const getTier = (score: number) => {
    if (score >= 7.5) return { label: 'CRITICAL / HIGH RISK', color: 'text-rose-400', bg: 'bg-rose-500/10', border: 'border-rose-500/30' };
    if (score >= 5.0) return { label: 'ELEVATED METABOLIC RISK', color: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/30' };
    if (score >= 3.0) return { label: 'MODERATE RISK', color: 'text-yellow-400', bg: 'bg-yellow-500/10', border: 'border-yellow-500/30' };
    return { label: 'OPTIMAL / LOW RISK', color: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/30' };
  };

  const currentTier = getTier(currentRiskScore);
  const simulatedTier = getTier(simulatedRiskScore);

  return (
    <div className="space-y-6">
      {/* Required Prototype Banner */}
      <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-4 flex items-start gap-3">
        <ShieldAlert className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
        <div>
          <span className="text-xs font-semibold uppercase tracking-wider text-amber-500">
            RESEARCH PROTOTYPE — NOT A DEPLOYED PRODUCT
          </span>
          <p className="text-xs text-slate-400 mt-1">
            Biostatistical risk stratification simulator for educational and preventive research demonstration. Not a certified clinical medical diagnosis or prescription.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Baseline Biometrics Column */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="font-semibold text-slate-100 flex items-center gap-2 text-sm">
              <HeartPulse className="w-4 h-4 text-rose-400" />
              Patient Baseline Biomarkers
            </h3>
            <span className="text-xs text-slate-400">Inputs</span>
          </div>

          {/* Daily Physical Activity Slider */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300">Daily Moderate Activity</span>
              <span className="font-mono text-emerald-400 font-semibold">{physicalActMin} min/day</span>
            </div>
            <input
              type="range"
              min="5"
              max="90"
              step="5"
              value={physicalActMin}
              onChange={(e) => setPhysicalActMin(parseInt(e.target.value))}
              aria-label="Daily Moderate Activity in minutes per day"
              className="w-full accent-emerald-500 bg-slate-800 h-2 rounded cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>5m (Sedentary)</span>
              <span>30m (WHO Target)</span>
              <span>90m</span>
            </div>
          </div>

          {/* BMI Slider */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300">Body Mass Index (BMI)</span>
              <span className="font-mono text-indigo-400 font-semibold">{bmi} kg/m²</span>
            </div>
            <input
              type="range"
              min="19.0"
              max="42.0"
              step="0.5"
              value={bmi}
              onChange={(e) => setBmi(parseFloat(e.target.value))}
              aria-label="Body Mass Index in kg/m2"
              className="w-full accent-indigo-500 bg-slate-800 h-2 rounded cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>19 (Normal)</span>
              <span>25 (Overweight)</span>
              <span>30+ (Obese)</span>
            </div>
          </div>

          {/* Fasting Glucose */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300">Fasting Blood Glucose</span>
              <span className="font-mono text-amber-400 font-semibold">{fastingGlucose} mg/dL</span>
            </div>
            <input
              type="range"
              min="75"
              max="160"
              step="1"
              value={fastingGlucose}
              onChange={(e) => setFastingGlucose(parseInt(e.target.value))}
              aria-label="Fasting Blood Glucose in mg/dL"
              className="w-full accent-amber-500 bg-slate-800 h-2 rounded cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>&lt;100 (Normal)</span>
              <span>100-125 (Prediabetes)</span>
              <span>126+</span>
            </div>
          </div>

          {/* Systolic BP */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300">Systolic Blood Pressure</span>
              <span className="font-mono text-rose-400 font-semibold">{systolicBp} mmHg</span>
            </div>
            <input
              type="range"
              min="105"
              max="165"
              step="1"
              value={systolicBp}
              onChange={(e) => setSystolicBp(parseInt(e.target.value))}
              aria-label="Systolic Blood Pressure in mmHg"
              className="w-full accent-rose-500 bg-slate-800 h-2 rounded cursor-pointer"
            />
          </div>

          {/* Age */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300">Patient Age</span>
              <span className="font-mono text-slate-200 font-semibold">{age} yrs</span>
            </div>
            <input
              type="range"
              min="25"
              max="75"
              step="1"
              value={age}
              onChange={(e) => setAge(parseInt(e.target.value))}
              aria-label="Patient Age in years"
              className="w-full accent-slate-400 bg-slate-800 h-2 rounded cursor-pointer"
            />
          </div>
        </div>

        {/* Outcomes & Intervention Simulator */}
        <div className="lg:col-span-2 space-y-6">
          {/* Comparative Risk Banner: Current vs Simulated */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Current Baseline Card */}
            <div className={`${currentTier.bg} border ${currentTier.border} rounded-xl p-5`}>
              <span className="text-xs text-slate-400 block mb-1">Current Baseline Risk</span>
              <div className="flex items-baseline gap-2">
                <span className={`text-4xl font-extrabold font-mono ${currentTier.color}`}>
                  {currentRiskScore}
                </span>
                <span className="text-xs text-slate-400">/ 10.0</span>
              </div>
              <span className={`text-xs font-semibold block mt-1 ${currentTier.color}`}>
                {currentTier.label}
              </span>
              <p className="text-[11px] text-slate-400 mt-2">
                Based on current activity ({physicalActMin}m) and biomarker profile.
              </p>
            </div>

            {/* Projected Post-Intervention Card */}
            <div className={`${simulatedTier.bg} border ${simulatedTier.border} rounded-xl p-5`}>
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs text-slate-400">Simulated Target Risk</span>
                {riskDelta > 0 && (
                  <span className="text-xs text-emerald-400 font-mono font-semibold flex items-center gap-1">
                    <TrendingDown className="w-3.5 h-3.5" /> -{riskDelta} pts
                  </span>
                )}
              </div>
              <div className="flex items-baseline gap-2">
                <span className={`text-4xl font-extrabold font-mono ${simulatedTier.color}`}>
                  {simulatedRiskScore}
                </span>
                <span className="text-xs text-slate-400">/ 10.0</span>
              </div>
              <span className={`text-xs font-semibold block mt-1 ${simulatedTier.color}`}>
                {simulatedTier.label}
              </span>
              <p className="text-[11px] text-slate-400 mt-2">
                Projected outcome after achieving targeted lifestyle increments.
              </p>
            </div>
          </div>

          {/* Interactive Lifestyle Modulation Testing */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <h4 className="font-semibold text-slate-100 text-sm flex items-center gap-2">
              <Flame className="w-4 h-4 text-emerald-400" />
              Simulate Targeted Lifestyle Prescription
            </h4>
            <p className="text-xs text-slate-400">
              Test how increasing daily exercise or reducing BMI modulates composite risk according to DPP clinical trial findings.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="p-3 bg-slate-800/60 rounded-lg space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300">Add Daily Physical Activity</span>
                  <span className="font-mono text-emerald-400 font-semibold">+{targetActivityAdd} min/day</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="45"
                  step="5"
                  value={targetActivityAdd}
                  onChange={(e) => setTargetActivityAdd(parseInt(e.target.value))}
                  aria-label="Add Daily Physical Activity in minutes per day"
                  className="w-full accent-emerald-500 bg-slate-800 h-2 rounded cursor-pointer"
                />
                <span className="text-[10px] text-slate-400 block">
                  New daily activity: {physicalActMin + targetActivityAdd} min/day
                </span>
              </div>

              <div className="p-3 bg-slate-800/60 rounded-lg space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300">Targeted BMI Reduction</span>
                  <span className="font-mono text-cyan-400 font-semibold">-{targetBmiLoss} kg/m²</span>
                </div>
                <input
                  type="range"
                  min="0.0"
                  max="4.0"
                  step="0.5"
                  value={targetBmiLoss}
                  onChange={(e) => setTargetBmiLoss(parseFloat(e.target.value))}
                  aria-label="Targeted BMI Reduction in kg/m2"
                  className="w-full accent-cyan-500 bg-slate-800 h-2 rounded cursor-pointer"
                />
                <span className="text-[10px] text-slate-400 block">
                  New projected BMI: {Math.max(18.5, bmi - targetBmiLoss).toFixed(1)} kg/m²
                </span>
              </div>
            </div>

            {/* Evidence-Backed Clinical Milestone Cards */}
            <div className="pt-3 border-t border-slate-800 grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="p-2.5 bg-slate-800/40 rounded border border-slate-800">
                <span className="text-[11px] font-semibold text-emerald-400 block">DPP 58% Milestone</span>
                <p className="text-[11px] text-slate-300 mt-1">
                  150 min/wk moderate activity prevents over half of type 2 diabetes transitions.
                </p>
              </div>

              <div className="p-2.5 bg-slate-800/40 rounded border border-slate-800">
                <span className="text-[11px] font-semibold text-cyan-400 block">Micro-Vascular Benefit</span>
                <p className="text-[11px] text-slate-300 mt-1">
                  Each +15m daily exercise reduces systolic vascular pressure by ~3-5 mmHg.
                </p>
              </div>

              <div className="p-2.5 bg-slate-800/40 rounded border border-slate-800">
                <span className="text-[11px] font-semibold text-indigo-400 block">Non-Insulin Uptake</span>
                <p className="text-[11px] text-slate-300 mt-1">
                  Muscular contractions clear glucose independently of pancreatic insulin resistance.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
