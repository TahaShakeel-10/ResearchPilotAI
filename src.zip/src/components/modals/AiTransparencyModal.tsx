/**
 * ResearchPilotAI - AI Transparency & Research Integrity Modal
 * Explicit boundary between AI synthesis and scientific truth.
 * Highlights safeguards, what AI did, and what AI did NOT establish.
 */

import React from 'react';
import { X, ShieldCheck, CheckCircle2, AlertOctagon, Scale, ShieldAlert, Award } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const AiTransparencyModal: React.FC<Props> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 sm:p-8 space-y-6 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute right-5 top-5 p-1 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="space-y-1.5 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Scale className="w-5 h-5 text-emerald-400" />
            <h2 className="text-lg font-bold text-slate-100">
              AI Transparency & Research Integrity Charter
            </h2>
          </div>
          <p className="text-xs text-slate-400">
            ResearchPilotAI operates under strict epistemic constraints to ensure academic credibility and prevent hallucination.
          </p>
        </div>

        {/* Two-Column Comparison */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          {/* What AI DID */}
          <div className="bg-slate-800/40 border border-slate-700/60 rounded-xl p-4 space-y-3">
            <span className="text-xs font-semibold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5 font-mono">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              What AI Did
            </span>
            <ul className="space-y-2 text-xs text-slate-300">
              <li className="flex items-start gap-2">
                <span className="text-emerald-400 font-bold">•</span>
                <span>Refined ambiguous research questions into testable formulations</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-emerald-400 font-bold">•</span>
                <span>Synthesized empirical peer-reviewed evidence and citation metadata</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-emerald-400 font-bold">•</span>
                <span>Recommended discipline-specific scientific methodologies</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-emerald-400 font-bold">•</span>
                <span>Calculated mathematical descriptive & regression metrics on empirical datasets</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-emerald-400 font-bold">•</span>
                <span>Identified unaddressed research gaps and literature contradictions</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-emerald-400 font-bold">•</span>
                <span>Generated testable hypotheses labeled with operational variables</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-emerald-400 font-bold">•</span>
                <span>Structured a 14-section academic mini research paper</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-emerald-400 font-bold">•</span>
                <span>Engineered functional interactive prototypes for applied demonstration</span>
              </li>
            </ul>
          </div>

          {/* What AI Did NOT Establish */}
          <div className="bg-slate-800/40 border border-slate-700/60 rounded-xl p-4 space-y-3">
            <span className="text-xs font-semibold text-rose-400 uppercase tracking-wider flex items-center gap-1.5 font-mono">
              <AlertOctagon className="w-4 h-4 text-rose-400" />
              What AI Did NOT Establish
            </span>
            <ul className="space-y-2 text-xs text-slate-300">
              <li className="flex items-start gap-2">
                <span className="text-rose-400 font-bold">•</span>
                <span>Definitive scientific truth or biological law</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-rose-400 font-bold">•</span>
                <span>Causal relationships without prospective controlled trial evidence</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-rose-400 font-bold">•</span>
                <span>Clinical medical diagnoses, prescriptions, or legal counsel</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-rose-400 font-bold">•</span>
                <span>Guaranteed intellectual property novelty without patent office search</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-rose-400 font-bold">•</span>
                <span>Peer-reviewed journal publication validity (requires human referees)</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Safeguards Enforced */}
        <div className="p-4 bg-slate-950/70 border border-slate-800 rounded-xl space-y-2 text-xs text-slate-300">
          <span className="font-semibold text-slate-200 uppercase tracking-wider text-[11px] block font-mono">
            Zero-Hallucination Safeguards Enforced:
          </span>
          <p className="leading-relaxed text-slate-400">
            ResearchPilotAI strictly forbids the fabrication of papers, authors, statistics, datasets, experimental outcomes, or fake DOI links. If relevant evidence cannot be retrieved, the system reports <span className="text-rose-400 font-mono">"Insufficient evidence available."</span> When statistical analysis is constrained, the engine outputs <span className="text-rose-400 font-mono">"Analysis could not be performed with the available data."</span>
          </p>
        </div>

        <div className="flex justify-end pt-2">
          <button
            onClick={onClose}
            className="py-2 px-5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold transition-colors"
          >
            I Understand the Epistemic Constraints
          </button>
        </div>
      </div>
    </div>
  );
};
