/**
 * ResearchPilotAI - New Investigation Modal
 * Prompts user for research question, discipline, goal, and optional dataset.
 * Supports quick launch of pre-built hackathon demos as well.
 */

import React, { useState } from 'react';
import { X, Sparkles, Upload, FileSpreadsheet, ArrowRight, BookOpen, Layers, Database } from 'lucide-react';
import { parseCsv, analyzeDataset } from '../../utils/dataEngine';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onStartInvestigation: (params: {
    question: string;
    discipline: string;
    goal: string;
    csvData?: string;
  }) => void;
  onSelectDemo: (demoKey: string) => void;
}

export const NewInvestigationModal: React.FC<Props> = ({
  isOpen,
  onClose,
  onStartInvestigation,
  onSelectDemo,
}) => {
  const [question, setQuestion] = useState<string>('');
  const [discipline, setDiscipline] = useState<string>('Auto Detect');
  const [goal, setGoal] = useState<string>('Explore a question');
  const [dataOption, setDataOption] = useState<'none' | 'csv' | 'sample'>('none');
  const [csvContent, setCsvContent] = useState<string>('');
  const [fileName, setFileName] = useState<string>('');

  if (!isOpen) return null;

  const disciplines = [
    'Auto Detect',
    'Computer Science & AI',
    'Data Science & Statistics',
    'Education & Learning Sciences',
    'Environmental & Climate Science',
    'Biology & Genetics',
    'Medicine & Public Health',
    'Economics & Finance',
    'Engineering & Robotics',
    'Social Sciences & Psychology',
    'Other / Interdisciplinary',
  ];

  const goals = [
    'Explore a question',
    'Test a hypothesis',
    'Find a research gap',
    'Analyze a dataset',
    'Develop a solution',
    'Build a prototype',
    'Generate a research paper',
  ];

  const sampleDatasets: Record<string, string> = {
    'Social Media & Study Focus': `student_id,social_media_hours,gpa,focus_score,screen_breaks\n1,4.5,2.8,45,2\n2,1.2,3.8,85,6\n3,3.0,3.2,60,4\n4,5.2,2.4,35,1\n5,2.1,3.6,78,5\n6,0.8,3.9,92,7\n7,3.5,3.0,55,3\n8,4.0,2.9,50,2`,
    'Renewable Microgrid Inverter Efficiency': `timestamp_h,solar_irradiance_wm2,battery_temp_c,inverter_eff_pct,power_output_kw\n1,450,28,94.2,3.8\n2,820,34,92.5,7.1\n3,950,38,90.8,8.2\n4,600,31,93.4,5.2\n5,200,24,95.1,1.8\n6,780,33,92.8,6.8`,
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFileName(file.name);
      const reader = new FileReader();
      reader.onload = (event) => {
        setCsvContent(event.target?.result as string);
      };
      reader.readAsText(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim()) return;

    onStartInvestigation({
      question: question.trim(),
      discipline,
      goal,
      csvData: dataOption !== 'none' ? csvContent : undefined,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full max-h-[92vh] overflow-y-auto p-6 sm:p-8 space-y-6 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute right-5 top-5 p-1 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="space-y-1 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-emerald-400" />
            <h2 className="text-lg font-bold text-slate-100">
              Start a Research Investigation
            </h2>
          </div>
          <p className="text-xs text-slate-400">
            Formulate your research question. Our 8 specialized AI agents will plan the methodology, retrieve literature, calculate data metrics, spot gaps, draft a mini paper, and prototype an innovation.
          </p>
        </div>

        {/* Quick Demo Selector */}
        <div className="p-3.5 bg-slate-800/40 rounded-xl border border-slate-700/60 space-y-2">
          <span className="text-[11px] font-mono text-emerald-400 uppercase tracking-wider block">
            Or Explore Preconfigured Hackathon Demos:
          </span>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <button
              type="button"
              onClick={() => {
                onSelectDemo('demo-education');
                onClose();
              }}
              className="p-2.5 rounded-lg bg-slate-800 hover:bg-slate-700/80 text-left border border-slate-700/60 hover:border-emerald-500/50 transition-all text-xs space-y-1"
            >
              <span className="font-semibold text-slate-200 block text-[11px]">Demo 1 — Education</span>
              <p className="text-[11px] text-slate-400 line-clamp-2">Sleep duration vs University student GPA</p>
            </button>

            <button
              type="button"
              onClick={() => {
                onSelectDemo('demo-environment');
                onClose();
              }}
              className="p-2.5 rounded-lg bg-slate-800 hover:bg-slate-700/80 text-left border border-slate-700/60 hover:border-cyan-500/50 transition-all text-xs space-y-1"
            >
              <span className="font-semibold text-slate-200 block text-[11px]">Demo 2 — Environment</span>
              <p className="text-[11px] text-slate-400 line-clamp-2">ML for Urban Catchment Flood Risk</p>
            </button>

            <button
              type="button"
              onClick={() => {
                onSelectDemo('demo-healthcare');
                onClose();
              }}
              className="p-2.5 rounded-lg bg-slate-800 hover:bg-slate-700/80 text-left border border-slate-700/60 hover:border-indigo-500/50 transition-all text-xs space-y-1"
            >
              <span className="font-semibold text-slate-200 block text-[11px]">Demo 3 — Healthcare</span>
              <p className="text-[11px] text-slate-400 line-clamp-2">Public data for metabolic disease risk</p>
            </button>
          </div>
        </div>

        {/* Custom Input Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Research Question */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-200 block">
              Research Question <span className="text-emerald-400">*</span>
            </label>
            <textarea
              required
              rows={3}
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="e.g., Can social media usage patterns affect university students' academic performance?"
              className="w-full p-3 bg-slate-800 border border-slate-700 rounded-xl text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 leading-relaxed"
            />
            <div className="flex gap-2 text-[11px] text-slate-400">
              <span>Try:</span>
              <button
                type="button"
                onClick={() => setQuestion("Can social media usage patterns affect university students' academic performance?")}
                className="text-emerald-400 hover:underline truncate"
              >
                "Can social media usage patterns affect university students' academic performance?"
              </button>
            </div>
          </div>

          {/* Discipline and Goal Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-300 block">
                Research Discipline (Optional)
              </label>
              <select
                value={discipline}
                onChange={(e) => setDiscipline(e.target.value)}
                className="w-full p-2.5 bg-slate-800 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
              >
                {disciplines.map(d => (
                  <option key={d} value={d}>{d}</option>
                ))}
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-300 block">
                Primary Research Goal
              </label>
              <select
                value={goal}
                onChange={(e) => setGoal(e.target.value)}
                className="w-full p-2.5 bg-slate-800 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
              >
                {goals.map(g => (
                  <option key={g} value={g}>{g}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Available Data Options */}
          <div className="space-y-2 pt-2 border-t border-slate-800">
            <label className="text-xs font-medium text-slate-300 block">
              Available Empirical Data
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => {
                  setDataOption('none');
                  setCsvContent('');
                }}
                className={`py-2 px-3 text-xs rounded-lg border text-center transition-all ${
                  dataOption === 'none'
                    ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300 font-medium'
                    : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-slate-200'
                }`}
              >
                No Dataset
              </button>

              <button
                type="button"
                onClick={() => setDataOption('csv')}
                className={`py-2 px-3 text-xs rounded-lg border text-center transition-all ${
                  dataOption === 'csv'
                    ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300 font-medium'
                    : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-slate-200'
                }`}
              >
                Upload CSV
              </button>

              <button
                type="button"
                onClick={() => setDataOption('sample')}
                className={`py-2 px-3 text-xs rounded-lg border text-center transition-all ${
                  dataOption === 'sample'
                    ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300 font-medium'
                    : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-slate-200'
                }`}
              >
                Sample Dataset
              </button>
            </div>

            {dataOption === 'csv' && (
              <div className="pt-2">
                <label className="flex flex-col items-center justify-center p-4 border-2 border-dashed border-slate-700 hover:border-slate-500 rounded-xl cursor-pointer bg-slate-800/40">
                  <Upload className="w-5 h-5 text-slate-400 mb-1" />
                  <span className="text-xs text-slate-300 font-medium">
                    {fileName ? fileName : 'Select or drop CSV file'}
                  </span>
                  <span className="text-[10px] text-slate-500">Comma-separated values</span>
                  <input
                    type="file"
                    accept=".csv,.txt"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                </label>
              </div>
            )}

            {dataOption === 'sample' && (
              <div className="pt-2 space-y-2">
                <span className="text-[11px] text-slate-400 block">Choose a template dataset:</span>
                <div className="grid grid-cols-2 gap-2">
                  {Object.entries(sampleDatasets).map(([name, csv]) => (
                    <button
                      key={name}
                      type="button"
                      onClick={() => setCsvContent(csv)}
                      className={`p-2 rounded border text-left text-xs ${
                        csvContent === csv
                          ? 'border-emerald-500 bg-emerald-950/30 text-emerald-300'
                          : 'border-slate-700 bg-slate-800 text-slate-300'
                      }`}
                    >
                      {name}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Submit Button */}
          <div className="pt-4 border-t border-slate-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="py-2 px-4 rounded-lg text-xs text-slate-400 hover:text-slate-200 hover:bg-slate-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!question.trim()}
              className="py-2.5 px-6 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold text-xs rounded-lg flex items-center gap-2 transition-all shadow-md"
            >
              <span>START INVESTIGATION</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
