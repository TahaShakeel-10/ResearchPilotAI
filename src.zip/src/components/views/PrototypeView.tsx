/**
 * ResearchPilotAI - Research-to-Prototype View (Agent 8)
 * Second signature feature: "Turn This Research Into Innovation"
 * Shows comprehensive engineering specification AND embeds a functional interactive prototype.
 */

import React, { useState } from 'react';
import { ResearchInvestigation } from '../../types/research';
import { SleepCircadianPlanner } from '../prototypes/SleepCircadianPlanner';
import { UrbanHydroPredictor } from '../prototypes/UrbanHydroPredictor';
import { MetabolicRiskSimulator } from '../prototypes/MetabolicRiskSimulator';
import { DynamicScenarioPrototype } from '../prototypes/DynamicScenarioPrototype';
import { 
  Rocket, 
  Cpu, 
  Users, 
  Sparkles, 
  Layers, 
  ShieldAlert, 
  Play, 
  Code2, 
  CheckCircle2, 
  Compass,
  ArrowRight,
  Database
} from 'lucide-react';

interface Props {
  investigation: ResearchInvestigation;
}

export const PrototypeView: React.FC<Props> = ({ investigation }) => {
  const { prototype } = investigation;
  const [activeTab, setActiveTab] = useState<'interactive' | 'specification'>('interactive');

  const renderActiveInteractivePrototype = () => {
    switch (prototype.interactiveComponentId) {
      case 'SleepCircadianPlanner':
        return <SleepCircadianPlanner />;
      case 'UrbanHydroPredictor':
        return <UrbanHydroPredictor />;
      case 'MetabolicRiskSimulator':
        return <MetabolicRiskSimulator />;
      default:
        return <DynamicScenarioPrototype investigation={investigation} />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-cyan-950/70 border border-cyan-500/40 text-cyan-300">
                AGENT 8 — RESEARCH-TO-PROTOTYPE ENGINE
              </span>
              <span className="text-xs text-slate-400 font-mono">Signature Innovation Translation</span>
            </div>
            <h2 className="text-base font-semibold text-slate-100 mt-1">
              "Turn This Research Into Innovation"
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Transforming academic findings into operational systems, simulation engines, and decision-support prototypes.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('interactive')}
              className={`py-1.5 px-3 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors ${
                activeTab === 'interactive'
                  ? 'bg-emerald-600 text-white font-semibold'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Play className="w-3.5 h-3.5" />
              <span>Interactive Prototype</span>
            </button>

            <button
              onClick={() => setActiveTab('specification')}
              className={`py-1.5 px-3 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors ${
                activeTab === 'specification'
                  ? 'bg-emerald-600 text-white font-semibold'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Code2 className="w-3.5 h-3.5" />
              <span>Full System Spec</span>
            </button>
          </div>
        </div>

        {/* Core Differentiator Callout */}
        <div className="pt-3 flex items-start gap-2.5 text-xs text-cyan-300 bg-cyan-500/5 p-3 rounded-lg border border-cyan-500/20">
          <Rocket className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
          <div>
            <strong className="text-cyan-200">Core Differentiator: </strong>
            "Research doesn't have to end with a paper. ResearchPilotAI helps transform findings into innovation."
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      {activeTab === 'interactive' ? (
        <div className="space-y-6">
          {/* Functional Component Container */}
          <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-6 sm:p-8">
            <div className="flex items-center justify-between pb-4 mb-6 border-b border-slate-800">
              <div>
                <span className="text-xs font-mono uppercase text-emerald-400">
                  Functional Live Prototype
                </span>
                <h3 className="text-lg font-bold text-slate-100">
                  {prototype.proposedSolution}
                </h3>
              </div>
              <span className="text-xs font-mono px-2.5 py-1 rounded bg-slate-800 text-slate-300 border border-slate-700">
                Mode: {prototype.prototypeType}
              </span>
            </div>

            {renderActiveInteractivePrototype()}
          </div>
        </div>
      ) : (
        /* Full Technical Specification Breakdown */
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Problem & Solution */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
              <div>
                <span className="text-[10px] font-mono uppercase text-rose-400 block mb-1">Identified Problem</span>
                <p className="text-xs text-slate-300 leading-relaxed">{prototype.problem}</p>
              </div>

              <div className="pt-3 border-t border-slate-800">
                <span className="text-[10px] font-mono uppercase text-emerald-400 block mb-1">Proposed Solution</span>
                <p className="text-xs text-slate-200 leading-relaxed font-medium">{prototype.proposedSolution}</p>
              </div>

              <div className="pt-3 border-t border-slate-800">
                <span className="text-[10px] font-mono uppercase text-cyan-400 block mb-1">Target Users</span>
                <p className="text-xs text-slate-300 leading-relaxed">{prototype.targetUsers}</p>
              </div>
            </div>

            {/* Architecture & AI Core */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
              <div>
                <span className="text-[10px] font-mono uppercase text-indigo-400 block mb-1">AI / Algorithmic Engine</span>
                <p className="text-xs text-slate-300 leading-relaxed">{prototype.aiComponent}</p>
              </div>

              <div className="pt-3 border-t border-slate-800">
                <span className="text-[10px] font-mono uppercase text-amber-400 block mb-1">Data Requirements</span>
                <p className="text-xs text-slate-300 leading-relaxed">{prototype.dataRequirements}</p>
              </div>

              <div className="pt-3 border-t border-slate-800">
                <span className="text-[10px] font-mono uppercase text-emerald-400 block mb-1">Technical Stack</span>
                <p className="text-xs text-slate-300 leading-relaxed font-mono">{prototype.technicalStack}</p>
              </div>
            </div>
          </div>

          {/* User Journey & Core Features */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                <Users className="w-4 h-4 text-emerald-400" />
                Target User Journey
              </h4>
              <ol className="space-y-2 text-xs text-slate-300 pl-4 list-decimal">
                {prototype.userJourney.map((step, i) => (
                  <li key={i} className="leading-relaxed pl-1">{step}</li>
                ))}
              </ol>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                <Layers className="w-4 h-4 text-cyan-400" />
                Core System Features
              </h4>
              <ul className="space-y-2 text-xs text-slate-300">
                {prototype.coreFeatures.map((feat, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{feat}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
