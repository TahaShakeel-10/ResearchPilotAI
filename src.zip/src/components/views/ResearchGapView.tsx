/**
 * ResearchPilotAI - Research Gap Detector View (Agent 4)
 * Signature feature analyzing established knowledge, evidence gaps, contradictions,
 * methodological limits, population blindspots, and potential research opportunities.
 * Enforces cautious epistemic vocabulary.
 */

import React from 'react';
import { ResearchInvestigation } from '../../types/research';
import { 
  Compass, 
  CheckCircle2, 
  HelpCircle, 
  GitCompare, 
  Microscope, 
  Globe2, 
  Lightbulb, 
  ShieldAlert,
  AlertTriangle,
  ArrowRight
} from 'lucide-react';

interface Props {
  investigation: ResearchInvestigation;
  onNavigateToHypothesis?: () => void;
}

export const ResearchGapView: React.FC<Props> = ({ investigation, onNavigateToHypothesis }) => {
  const { gaps } = investigation;

  return (
    <div className="space-y-6">
      {/* Signature Feature Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-rose-950/70 border border-rose-500/40 text-rose-300">
                AGENT 4 — RESEARCH GAP DETECTOR
              </span>
              <span className="text-xs text-slate-400 font-mono">Signature Intelligence Engine</span>
            </div>
            <h2 className="text-base font-semibold text-slate-100 mt-1">
              Systematic Scientific Gap & Contradiction Identification
            </h2>
          </div>
          <div className="text-xs text-slate-400 bg-slate-800/80 px-3 py-1.5 rounded-lg border border-slate-700/60 font-mono">
            Epistemic Protocol: Strict Cautious Phrasing
          </div>
        </div>

        {/* Epistemic Cautious Language Standard */}
        <div className="pt-3 flex items-start gap-2.5 text-xs text-slate-300 bg-amber-500/5 p-3 rounded-lg border border-amber-500/20">
          <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <div>
            <strong className="text-amber-300">Research Integrity Standard: </strong>
            Gaps are never arbitrarily labeled as absolute "novel discoveries". The system employs measured scientific criteria:
            <span className="text-slate-400 italic ml-1">"appears underexplored" · "limited evidence was identified" · "requires further investigation"</span>.
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Established Knowledge */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <h3 className="font-semibold text-slate-100 text-sm flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              Established Knowledge (Well Supported)
            </h3>
            <span className="text-xs text-emerald-400 font-mono">High Consensus</span>
          </div>

          <div className="space-y-3">
            {gaps.establishedKnowledge.map((item, i) => (
              <div key={i} className="p-3.5 bg-slate-800/40 rounded-lg border border-slate-700/40 space-y-1.5">
                <h4 className="font-medium text-xs text-slate-100">{item.title}</h4>
                <p className="text-xs text-slate-300 leading-relaxed">{item.description}</p>
                <div className="text-[11px] text-slate-400 pt-1 font-mono">
                  Supported by: {item.supportingSources.join(', ')}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Evidence Gaps */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <h3 className="font-semibold text-slate-100 text-sm flex items-center gap-2">
              <HelpCircle className="w-4 h-4 text-rose-400" />
              Evidence Gaps (Insufficiently Studied)
            </h3>
            <span className="text-xs text-rose-400 font-mono">Unresolved</span>
          </div>

          <div className="space-y-3">
            {gaps.evidenceGaps.map((item, i) => (
              <div key={i} className="p-3.5 bg-slate-800/40 rounded-lg border border-slate-700/40 space-y-2">
                <h4 className="font-medium text-xs text-slate-100">{item.gap}</h4>
                <p className="text-xs text-slate-300 leading-relaxed">{item.whyItMatters}</p>
                <div className="p-2 bg-slate-900/60 rounded text-[11px] text-amber-300/90 italic border border-slate-800">
                  {item.cautiousNote}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Literature Contradictions */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <h3 className="font-semibold text-slate-100 text-sm flex items-center gap-2">
              <GitCompare className="w-4 h-4 text-amber-400" />
              Contradictions & Disagreements
            </h3>
            <span className="text-xs text-amber-400 font-mono">Debated</span>
          </div>

          <div className="space-y-3">
            {gaps.contradictions.map((item, i) => (
              <div key={i} className="p-3.5 bg-slate-800/40 rounded-lg border border-slate-700/40 space-y-2">
                <h4 className="font-medium text-xs text-slate-100">{item.topic}</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <div className="p-2 bg-slate-900/50 rounded border border-slate-800">
                    <span className="text-[10px] text-slate-400 uppercase font-mono block">Perspective A</span>
                    <p className="text-slate-300 text-[11px] mt-0.5">{item.sideA}</p>
                  </div>
                  <div className="p-2 bg-slate-900/50 rounded border border-slate-800">
                    <span className="text-[10px] text-slate-400 uppercase font-mono block">Perspective B</span>
                    <p className="text-slate-300 text-[11px] mt-0.5">{item.sideB}</p>
                  </div>
                </div>
                <p className="text-[11px] text-emerald-400/90 pt-1 font-mono">
                  Synthesized Status: {item.resolutionStatus}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Methodological Gaps */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <h3 className="font-semibold text-slate-100 text-sm flex items-center gap-2">
              <Microscope className="w-4 h-4 text-cyan-400" />
              Methodological Gaps & Approaches
            </h3>
            <span className="text-xs text-cyan-400 font-mono">Protocol Deficits</span>
          </div>

          <div className="space-y-3">
            {gaps.methodologicalGaps.map((item, i) => (
              <div key={i} className="p-3.5 bg-slate-800/40 rounded-lg border border-slate-700/40 space-y-1.5">
                <h4 className="font-medium text-xs text-slate-100">{item.area}</h4>
                <p className="text-xs text-rose-300/90">
                  <strong className="text-slate-400">Limitation: </strong>{item.limitationInLiterature}
                </p>
                <p className="text-xs text-cyan-300/90">
                  <strong className="text-slate-400">Suggested Modern Protocol: </strong>{item.suggestedApproach}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Population & Geographic Gaps + Potential Opportunities */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Population Gaps */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
          <h3 className="font-semibold text-slate-100 text-sm flex items-center gap-2">
            <Globe2 className="w-4 h-4 text-indigo-400" />
            Population & Geographic Underrepresentation
          </h3>
          <p className="text-xs text-slate-400">
            Are specific cohorts, demographics, or geographic areas omitted from the published literature?
          </p>

          <div className="space-y-2 pt-1">
            {gaps.populationGeographicGaps.map((item, i) => (
              <div key={i} className="p-3 bg-slate-800/40 rounded-lg border border-slate-700/40 text-xs">
                <span className="font-medium text-slate-200 block mb-1">{item.underrepresentedDomain}</span>
                <p className="text-slate-400 leading-relaxed">{item.context}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Potential Research Opportunities */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3 flex flex-col justify-between">
          <div>
            <h3 className="font-semibold text-slate-100 text-sm flex items-center gap-2">
              <Lightbulb className="w-4 h-4 text-amber-400" />
              Actionable Research Opportunities
            </h3>
            <p className="text-xs text-slate-400">
              Questions that could reasonably and rigorously be investigated next.
            </p>

            <div className="space-y-2 pt-2">
              {gaps.potentialOpportunities.map((item, i) => (
                <div key={i} className="p-3 bg-slate-800/40 rounded-lg border border-slate-700/40 text-xs space-y-1">
                  <p className="text-slate-200 font-medium">{item.opportunity}</p>
                  <span className="text-[11px] text-emerald-400 font-mono block">
                    Feasibility: {item.feasibility}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {onNavigateToHypothesis && (
            <button
              onClick={onNavigateToHypothesis}
              className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs rounded-lg flex items-center justify-center gap-2 transition-colors mt-3"
            >
              <span>Translate Gaps into Testable Hypotheses</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
