/**
 * ResearchPilotAI - Landing Page (Section 26)
 * Hero, workflow walkthrough, differentiators, and demo launches.
 */

import React from 'react';
import { 
  Sparkles, 
  ArrowRight, 
  Play, 
  ShieldCheck, 
  Cpu, 
  Compass, 
  BookOpen, 
  Database, 
  Search, 
  FlaskConical, 
  FileText, 
  Rocket,
  CheckCircle2,
  Layers,
  GraduationCap,
  Trees,
  HeartPulse,
  HelpCircle
} from 'lucide-react';

interface Props {
  onStartResearch: () => void;
  onExploreDemo: (demoKey?: string) => void;
}

export const LandingPage: React.FC<Props> = ({ onStartResearch, onExploreDemo }) => {
  return (
    <div className="space-y-16 max-w-6xl mx-auto py-8 px-4">
      {/* Hero Section */}
      <div className="text-center space-y-6 pt-6">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-mono bg-emerald-950/80 border border-emerald-500/40 text-emerald-300">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Domain-Agnostic Multi-Agent Research & Innovation Engine</span>
        </div>

        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-100 tracking-tight leading-tight">
          ResearchPilotAI
        </h1>

        <p className="text-xl sm:text-2xl font-serif italic text-emerald-400">
          From Question to Discovery. From Discovery to Innovation.
        </p>

        <p className="max-w-2xl mx-auto text-sm sm:text-base text-slate-300 leading-relaxed font-normal">
          An AI research agent that transforms research questions into evidence-backed investigations, research insights, mini papers, and functional prototypes.
        </p>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
          <button
            onClick={onStartResearch}
            className="w-full sm:w-auto py-3 px-8 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm rounded-xl flex items-center justify-center gap-2 transition-all shadow-lg hover:shadow-emerald-900/40 cursor-pointer"
          >
            <span>Start Research</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            onClick={() => onExploreDemo('demo-education')}
            className="w-full sm:w-auto py-3 px-8 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-sm rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer"
          >
            <Play className="w-4 h-4 text-emerald-400" />
            <span>Explore Demo</span>
          </button>
        </div>
      </div>

      {/* Core Differentiator Banner */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 relative overflow-hidden">
          <div className="text-[10px] font-mono text-emerald-400 uppercase tracking-widest block mb-2">
            CORE PHILOSOPHY 01
          </div>
          <blockquote className="text-lg font-serif font-bold text-slate-100 leading-snug">
            "ResearchPilotAI doesn't just answer research questions. It investigates them."
          </blockquote>
          <p className="text-xs text-slate-400 mt-2">
            Rather than one giant AI summary, you observe the true scientific process: literature review, empirical statistical tests, gap analysis, and testable hypotheses.
          </p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 relative overflow-hidden">
          <div className="text-[10px] font-mono text-cyan-400 uppercase tracking-widest block mb-2">
            CORE PHILOSOPHY 02
          </div>
          <blockquote className="text-lg font-serif font-bold text-slate-100 leading-snug">
            "Research doesn't have to end with a paper. ResearchPilotAI helps transform findings into innovation."
          </blockquote>
          <p className="text-xs text-slate-400 mt-2">
            Translates academic findings into operational software specifications, simulation models, and functional interactive prototypes.
          </p>
        </div>
      </div>

      {/* How It Works Workflow Steps */}
      <div className="space-y-6">
        <div className="text-center space-y-1">
          <span className="text-xs font-mono uppercase tracking-wider text-emerald-400">
            Systematic Methodology
          </span>
          <h2 className="text-2xl font-bold text-slate-100">How It Works</h2>
          <p className="text-xs text-slate-400">
            Eight specialized AI agents collaborate across the end-to-end scientific lifecycle.
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
          {[
            { num: '01', title: 'Question', desc: 'Refine & scope problem', icon: HelpCircle },
            { num: '02', title: 'Discover', desc: 'Retrieve verified literature', icon: BookOpen },
            { num: '03', title: 'Investigate', desc: 'Empirical data modeling', icon: Database },
            { num: '04', title: 'Discover Gaps', desc: 'Isolate literature deficits', icon: Search },
            { num: '05', title: 'Hypothesize', desc: 'Formulate testable propositions', icon: FlaskConical },
            { num: '06', title: 'Write Paper', desc: '14-section mini paper', icon: FileText },
            { num: '07', title: 'Prototype', desc: 'Applied live innovation', icon: Rocket },
          ].map((step, i) => {
            const Icon = step.icon;
            return (
              <div
                key={step.num}
                className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-2 hover:border-slate-700 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs text-emerald-400 font-bold">{step.num}</span>
                  <Icon className="w-4 h-4 text-slate-400" />
                </div>
                <h4 className="font-semibold text-xs text-slate-200">{step.title}</h4>
                <p className="text-[11px] text-slate-400">{step.desc}</p>
              </div>
            );
          })}
        </div>
      </div>

      {/* Preconfigured Hackathon Demos Showcase */}
      <div className="space-y-6">
        <div className="text-center space-y-1">
          <span className="text-xs font-mono uppercase tracking-wider text-cyan-400">
            Live Presentation Demos
          </span>
          <h2 className="text-2xl font-bold text-slate-100">Cross-Disciplinary Investigations</h2>
          <p className="text-xs text-slate-400">
            Domain-agnostic architecture illustrated across Education, Environment, and Healthcare.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Demo 1 */}
          <div
            onClick={() => onExploreDemo('demo-education')}
            className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4 hover:border-emerald-500/50 transition-all cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-mono text-emerald-400 uppercase tracking-wider">Demo 1 · Education</span>
              <h3 className="font-bold text-sm text-slate-100 group-hover:text-emerald-300 transition-colors mt-0.5">
                Sleep Duration & Academic GPA
              </h3>
              <p className="text-xs text-slate-400 mt-2 line-clamp-3">
                Analyzes student sleep hours, stress, and GPA with Okano et al. (2019) literature; generates Circadian Study Planner prototype.
              </p>
            </div>
            <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-emerald-400 font-medium">
              <span>Launch Investigation</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Demo 2 */}
          <div
            onClick={() => onExploreDemo('demo-environment')}
            className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4 hover:border-cyan-500/50 transition-all cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <Trees className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-mono text-cyan-400 uppercase tracking-wider">Demo 2 · Environment</span>
              <h3 className="font-bold text-sm text-slate-100 group-hover:text-cyan-300 transition-colors mt-0.5">
                ML for Urban Catchment Flood Risk
              </h3>
              <p className="text-xs text-slate-400 mt-2 line-clamp-3">
                Models precipitation, impervious pavement, and drainage limits with Mosavi et al. (2018); produces HydroPredict early-warning tool.
              </p>
            </div>
            <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-cyan-400 font-medium">
              <span>Launch Investigation</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Demo 3 */}
          <div
            onClick={() => onExploreDemo('demo-healthcare')}
            className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4 hover:border-indigo-500/50 transition-all cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <HeartPulse className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-mono text-indigo-400 uppercase tracking-wider">Demo 3 · Healthcare</span>
              <h3 className="font-bold text-sm text-slate-100 group-hover:text-indigo-300 transition-colors mt-0.5">
                Cardiometabolic Disease Risk Factors
              </h3>
              <p className="text-xs text-slate-400 mt-2 line-clamp-3">
                Evaluates physical activity, BMI, and glucose with Knowler et al. (2002) DPP trial; yields Metabolic Sentinel simulator prototype.
              </p>
            </div>
            <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-indigo-400 font-medium">
              <span>Launch Investigation</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        </div>
      </div>

      {/* Why ResearchPilotAI? */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 space-y-6">
        <div className="text-center space-y-1">
          <span className="text-xs font-mono uppercase tracking-wider text-emerald-400">
            Architectural Strengths
          </span>
          <h2 className="text-2xl font-bold text-slate-100">Why ResearchPilotAI?</h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 pt-2">
          {[
            { title: 'Evidence-Backed Research', desc: 'Central Evidence Layer with explicit labels: Verified Source, Data-Derived, AI Inference, Hypothesis, or Insufficient.' },
            { title: 'Multi-Agent Investigation', desc: 'Specialized distinct agent prompts for planning, literature extraction, math analysis, gap detection, and prototyping.' },
            { title: 'Domain-Agnostic Engine', desc: 'Designed for STEM, environmental, public health, education, economics, and humanities queries without pre-baked bias.' },
            { title: 'Research-Gap Discovery', desc: 'Signature detector revealing established consensus, literature blindspots, contradictions, and methodological shortcomings.' },
            { title: 'Calculated Data Analysis', desc: 'Real statistical formulas (mean, std dev, Pearson correlations, OLS regression) computed directly from uploaded data.' },
            { title: 'Research-to-Prototype', desc: 'Converts research findings into functional interactive web tools, simulators, and decision-support engines.' },
          ].map((item, idx) => (
            <div key={idx} className="space-y-1.5 p-4 rounded-xl bg-slate-800/40 border border-slate-800">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <h4 className="font-semibold text-xs text-slate-200">{item.title}</h4>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed pl-6">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
