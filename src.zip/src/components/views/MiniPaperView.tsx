/**
 * ResearchPilotAI - Mini Paper Generator View (Agent 7)
 * Renders complete 14-section structured scholarly paper with Abstract, Keywords, and verified References.
 * Includes "Generate Report" and "Export Manuscript" features.
 */

import React, { useState } from 'react';
import { ResearchInvestigation } from '../../types/research';
import { 
  FileText, 
  Download, 
  Printer, 
  Copy, 
  Check, 
  BookOpen, 
  ExternalLink, 
  Sparkles,
  Award,
  Share2
} from 'lucide-react';

interface Props {
  investigation: ResearchInvestigation;
}

export const MiniPaperView: React.FC<Props> = ({ investigation }) => {
  const { paper } = investigation;
  const [copied, setCopied] = useState<boolean>(false);
  const [activeSection, setActiveSection] = useState<string>('all');

  const handleCopyMarkdown = () => {
    const md = `# ${paper.title}

## Abstract
${paper.abstract}

**Keywords:** ${paper.keywords.join(', ')}

### 1. Introduction
${paper.sections.introduction}

### 2. Research Problem
${paper.sections.researchProblem}

### 3. Research Question
${paper.sections.researchQuestion}

### 4. Objectives
${paper.sections.objectives.map((o, i) => `${i + 1}. ${o}`).join('\n')}

### 5. Literature Review
${paper.sections.literatureReview}

### 6. Research Gap
${paper.sections.researchGap}

### 7. Hypothesis
${paper.sections.hypothesis}

### 8. Methodology
${paper.sections.methodology}

### 9. Data and Analysis
${paper.sections.dataAndAnalysis}

### 10. Results
${paper.sections.results}

### 11. Discussion
${paper.sections.discussion}

### 12. Limitations
${paper.sections.limitations}

### 13. Conclusion
${paper.sections.conclusion}

### 14. Future Research
${paper.sections.futureResearch}

## References
${paper.references.map(r => `* [${r.id}] ${r.citationText} ${r.url || ''}`).join('\n')}
`;
    navigator.clipboard.writeText(md);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Top Action Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-indigo-950/70 border border-indigo-500/40 text-indigo-300">
              AGENT 7 — MINI PAPER GENERATOR
            </span>
            <span className="text-xs text-slate-400 font-mono">Peer-Reviewed Style Structure</span>
          </div>
          <h2 className="text-base font-semibold text-slate-100 mt-1">
            Structured 14-Section Scholarly Mini Research Paper
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Original analysis mathematically computed; citations mapped exclusively to verified literature.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopyMarkdown}
            className="py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied Markdown' : 'Copy Markdown'}</span>
          </button>

          <button
            onClick={handlePrint}
            className="py-1.5 px-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Generate Report / Print</span>
          </button>
        </div>
      </div>

      {/* Academic Paper Card Container */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-10 space-y-8 max-w-4xl mx-auto shadow-xl">
        {/* Paper Header */}
        <div className="text-center space-y-4 pb-6 border-b border-slate-800">
          <span className="text-xs font-mono uppercase tracking-widest text-emerald-400">
            Research Investigation Report · {investigation.discipline}
          </span>
          <h1 className="text-xl sm:text-2xl font-serif font-bold text-slate-100 leading-tight">
            {paper.title}
          </h1>
          <div className="flex items-center justify-center gap-2 text-xs text-slate-400 font-mono">
            <span>ResearchPilotAI Multi-Agent Synthesis</span>
            <span>·</span>
            <span>{new Date(investigation.createdAt).toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' })}</span>
          </div>
        </div>

        {/* Abstract Box */}
        <div className="p-5 bg-slate-800/50 rounded-xl border border-slate-700/60 space-y-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200 font-mono">
            Abstract
          </h3>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed text-justify">
            {paper.abstract}
          </p>
          <div className="pt-2 flex flex-wrap items-center gap-1.5 text-xs text-slate-400">
            <strong className="text-slate-300 font-mono text-[11px]">Keywords:</strong>
            {paper.keywords.map((kw, i) => (
              <span key={i} className="text-slate-400">
                {kw}{i < paper.keywords.length - 1 ? ' · ' : ''}
              </span>
            ))}
          </div>
        </div>

        {/* 14 Sections Content */}
        <div className="space-y-6 text-xs sm:text-sm text-slate-300 leading-relaxed">
          {/* 1. Introduction */}
          <section className="space-y-2">
            <h3 className="text-sm font-bold text-slate-100 font-serif border-b border-slate-800/80 pb-1">
              1. Introduction
            </h3>
            <p>{paper.sections.introduction}</p>
          </section>

          {/* 2. Research Problem */}
          <section className="space-y-2">
            <h3 className="text-sm font-bold text-slate-100 font-serif border-b border-slate-800/80 pb-1">
              2. Research Problem
            </h3>
            <p>{paper.sections.researchProblem}</p>
          </section>

          {/* 3. Research Question */}
          <section className="space-y-2">
            <h3 className="text-sm font-bold text-slate-100 font-serif border-b border-slate-800/80 pb-1">
              3. Research Question
            </h3>
            <p className="font-medium text-slate-200 bg-slate-800/30 p-3 rounded border border-slate-800">
              "{paper.sections.researchQuestion}"
            </p>
          </section>

          {/* 4. Objectives */}
          <section className="space-y-2">
            <h3 className="text-sm font-bold text-slate-100 font-serif border-b border-slate-800/80 pb-1">
              4. Objectives
            </h3>
            <ul className="list-decimal pl-5 space-y-1">
              {paper.sections.objectives.map((obj, i) => (
                <li key={i}>{obj}</li>
              ))}
            </ul>
          </section>

          {/* 5. Literature Review */}
          <section className="space-y-2">
            <h3 className="text-sm font-bold text-slate-100 font-serif border-b border-slate-800/80 pb-1">
              5. Literature Review
            </h3>
            <p>{paper.sections.literatureReview}</p>
          </section>

          {/* 6. Research Gap */}
          <section className="space-y-2">
            <h3 className="text-sm font-bold text-slate-100 font-serif border-b border-slate-800/80 pb-1">
              6. Research Gap
            </h3>
            <p className="bg-rose-950/20 p-3 rounded border border-rose-900/40 text-slate-300">
              {paper.sections.researchGap}
            </p>
          </section>

          {/* 7. Hypothesis */}
          <section className="space-y-2">
            <h3 className="text-sm font-bold text-slate-100 font-serif border-b border-slate-800/80 pb-1">
              7. Proposed Hypothesis
            </h3>
            <p className="bg-orange-950/20 p-3 rounded border border-orange-900/40 text-slate-300">
              <strong className="text-orange-400 block text-xs font-mono mb-1">PROPOSED HYPOTHESIS:</strong>
              {paper.sections.hypothesis}
            </p>
          </section>

          {/* 8. Methodology */}
          <section className="space-y-2">
            <h3 className="text-sm font-bold text-slate-100 font-serif border-b border-slate-800/80 pb-1">
              8. Methodology
            </h3>
            <p>{paper.sections.methodology}</p>
          </section>

          {/* 9. Data and Analysis */}
          <section className="space-y-2">
            <h3 className="text-sm font-bold text-slate-100 font-serif border-b border-slate-800/80 pb-1">
              9. Data and Analysis
            </h3>
            <p>{paper.sections.dataAndAnalysis}</p>
          </section>

          {/* 10. Results */}
          <section className="space-y-2">
            <h3 className="text-sm font-bold text-slate-100 font-serif border-b border-slate-800/80 pb-1">
              10. Results
            </h3>
            <p>{paper.sections.results}</p>
          </section>

          {/* 11. Discussion */}
          <section className="space-y-2">
            <h3 className="text-sm font-bold text-slate-100 font-serif border-b border-slate-800/80 pb-1">
              11. Discussion
            </h3>
            <p>{paper.sections.discussion}</p>
          </section>

          {/* 12. Limitations */}
          <section className="space-y-2">
            <h3 className="text-sm font-bold text-slate-100 font-serif border-b border-slate-800/80 pb-1">
              12. Limitations
            </h3>
            <p>{paper.sections.limitations}</p>
          </section>

          {/* 13. Conclusion */}
          <section className="space-y-2">
            <h3 className="text-sm font-bold text-slate-100 font-serif border-b border-slate-800/80 pb-1">
              13. Conclusion
            </h3>
            <p>{paper.sections.conclusion}</p>
          </section>

          {/* 14. Future Research */}
          <section className="space-y-2">
            <h3 className="text-sm font-bold text-slate-100 font-serif border-b border-slate-800/80 pb-1">
              14. Future Research
            </h3>
            <p>{paper.sections.futureResearch}</p>
          </section>
        </div>

        {/* References Section */}
        <div className="pt-6 border-t border-slate-800 space-y-3">
          <h3 className="text-sm font-bold text-slate-100 font-serif flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-emerald-400" />
            References (No Fabricated Citations)
          </h3>

          <div className="space-y-2 text-xs text-slate-400">
            {paper.references.map((ref) => (
              <div key={ref.id} className="p-3 bg-slate-800/40 rounded-lg flex items-start justify-between gap-3">
                <span>
                  <strong className="text-slate-300">[{ref.id}]</strong> {ref.citationText}
                </span>
                {ref.url && (
                  <a
                    href={ref.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-cyan-400 hover:underline flex items-center gap-1 text-[11px] shrink-0"
                  >
                    <span>DOI Link</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
