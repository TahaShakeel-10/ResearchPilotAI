/**
 * ResearchPilotAI - Investigation Workflow & Stage Tracker (Screen 17)
 * Tracks the 8 sequential execution stages of the multi-agent pipeline.
 * Displays genuine status updates and agent collaboration.
 */

import React from 'react';
import { PipelineStage, ResearchInvestigation } from '../../types/research';
import { 
  CheckCircle2, 
  Loader2, 
  HelpCircle, 
  Compass, 
  BookOpen, 
  Database, 
  Search, 
  FlaskConical, 
  FileText, 
  Rocket, 
  ArrowRight,
  Sparkles
} from 'lucide-react';

interface Props {
  currentStage: PipelineStage;
  isExecuting: boolean;
  statusMessage: string;
  investigation: ResearchInvestigation;
  onSelectTab: (tab: any) => void;
}

export const InvestigationWorkflow: React.FC<Props> = ({
  currentStage,
  isExecuting,
  statusMessage,
  investigation,
  onSelectTab,
}) => {
  const stages: Array<{
    id: PipelineStage;
    number: number;
    title: string;
    agent: string;
    icon: any;
    targetTab: string;
  }> = [
    { id: 'question', number: 1, title: 'Question Refinement', agent: 'Agent 1 — Planner', icon: HelpCircle, targetTab: 'investigation' },
    { id: 'plan', number: 2, title: 'Research Planning', agent: 'Agent 1 — Planner', icon: Compass, targetTab: 'investigation' },
    { id: 'discover', number: 3, title: 'Evidence Discovery', agent: 'Agent 2 — Literature', icon: BookOpen, targetTab: 'evidence' },
    { id: 'analyze', number: 4, title: 'Data Analysis', agent: 'Agent 3 — Analyst', icon: Database, targetTab: 'data-analysis' },
    { id: 'gap', number: 5, title: 'Gap Detection', agent: 'Agent 4 — Gap Detector', icon: Search, targetTab: 'research-gaps' },
    { id: 'hypothesis', number: 6, title: 'Hypothesis Generation', agent: 'Agent 5 — Hypotheses', icon: FlaskConical, targetTab: 'hypotheses' },
    { id: 'paper', number: 7, title: 'Mini Paper Generator', agent: 'Agent 7 — Mini Paper', icon: FileText, targetTab: 'mini-paper' },
    { id: 'prototype', number: 8, title: 'Research-to-Prototype', agent: 'Agent 8 — Prototype', icon: Rocket, targetTab: 'prototype' },
  ];

  const stageOrder: PipelineStage[] = ['question', 'plan', 'discover', 'analyze', 'gap', 'hypothesis', 'paper', 'prototype'];
  const currentIndex = stageOrder.indexOf(currentStage);

  return (
    <div className="space-y-6">
      {/* Real-time Status Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800">
          <div>
            <span className="text-[10px] font-mono uppercase text-emerald-400 tracking-wider block">
              MULTI-AGENT RESEARCH ORCHESTRATION PIPELINE
            </span>
            <h2 className="text-base font-semibold text-slate-100 mt-0.5">
              {investigation.title}
            </h2>
          </div>

          <div className="flex items-center gap-2">
            {isExecuting ? (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-mono font-medium bg-emerald-950/70 border border-emerald-500/40 text-emerald-300">
                <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-400" />
                <span>Executing Agents</span>
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-mono font-medium bg-slate-800 border border-slate-700 text-slate-300">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Investigation Complete</span>
              </span>
            )}
          </div>
        </div>

        {/* Live Meaningful Status String */}
        {isExecuting && statusMessage && (
          <div className="p-3 bg-slate-800/60 rounded-lg border border-slate-700/60 flex items-center gap-3 text-xs text-slate-200 animate-pulse font-mono">
            <Sparkles className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{statusMessage}</span>
          </div>
        )}
      </div>

      {/* 8-Stage Progress Tracker Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {stages.map((st, idx) => {
          const isDone = !isExecuting || idx < currentIndex;
          const isCurrent = isExecuting && idx === currentIndex;
          const isPending = isExecuting && idx > currentIndex;
          const Icon = st.icon;

          return (
            <div
              key={st.id}
              onClick={() => onSelectTab(st.targetTab)}
              className={`p-4 rounded-xl border transition-all cursor-pointer relative overflow-hidden ${
                isCurrent
                  ? 'bg-slate-900 border-emerald-500/60 ring-1 ring-emerald-500/40 shadow-lg'
                  : isDone
                  ? 'bg-slate-900/90 border-slate-800 hover:border-slate-700'
                  : 'bg-slate-900/40 border-slate-800/50 opacity-50 cursor-not-allowed'
              }`}
            >
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="font-mono text-[11px] text-slate-400 font-semibold">
                  STAGE {st.number}
                </span>
                {isCurrent ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-400" />
                ) : isDone ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                ) : (
                  <span className="w-2 h-2 rounded-full bg-slate-700" />
                )}
              </div>

              <div className="flex items-center gap-2 mb-1">
                <Icon className={`w-4 h-4 ${isCurrent ? 'text-emerald-400' : isDone ? 'text-slate-300' : 'text-slate-600'}`} />
                <h4 className="font-semibold text-xs text-slate-100">{st.title}</h4>
              </div>

              <span className="text-[10px] font-mono text-slate-500 block">
                {st.agent}
              </span>

              {isDone && (
                <div className="mt-3 pt-2 border-t border-slate-800 flex items-center justify-between text-[11px] text-emerald-400">
                  <span>View Details</span>
                  <ArrowRight className="w-3 h-3" />
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Investigation Details Quick Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
        <h3 className="font-semibold text-sm text-slate-100">Research Plan Overview</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div className="p-3 bg-slate-800/40 rounded-lg space-y-1">
            <span className="font-semibold text-slate-400 block font-mono text-[11px]">REFINED QUESTION:</span>
            <p className="text-slate-200">{investigation.plan.refined_question}</p>
          </div>
          <div className="p-3 bg-slate-800/40 rounded-lg space-y-1">
            <span className="font-semibold text-slate-400 block font-mono text-[11px]">RECOMMENDED METHODOLOGY:</span>
            <p className="text-slate-200">{investigation.plan.suggested_methodology}</p>
          </div>
        </div>

        <div className="space-y-1 pt-1">
          <span className="text-[11px] font-mono text-slate-400 block">DEFINED SUB-QUESTIONS:</span>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
            {investigation.plan.sub_questions.map((sq, i) => (
              <div key={i} className="p-2.5 bg-slate-800/20 rounded border border-slate-800 text-slate-300">
                • {sq}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
