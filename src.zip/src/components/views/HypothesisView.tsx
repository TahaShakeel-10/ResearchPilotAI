/**
 * ResearchPilotAI - Hypothesis Generator View (Agent 5)
 * Displays rigorously structured, testable hypotheses.
 * Each hypothesis is clearly labeled PROPOSED HYPOTHESIS with variables, rationale, methodology, and limitations.
 */

import React from 'react';
import { ResearchInvestigation } from '../../types/research';
import { 
  HelpCircle, 
  Target, 
  ArrowRight, 
  AlertTriangle, 
  ShieldAlert, 
  FlaskConical, 
  Sliders, 
  FileText 
} from 'lucide-react';

interface Props {
  investigation: ResearchInvestigation;
  onNavigateToPaper?: () => void;
}

export const HypothesisView: React.FC<Props> = ({ investigation, onNavigateToPaper }) => {
  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-orange-950/70 border border-orange-500/40 text-orange-300">
                AGENT 5 — HYPOTHESIS GENERATOR
              </span>
              <span className="text-xs text-slate-400 font-mono">Testable Empirical Formulations</span>
            </div>
            <h2 className="text-base font-semibold text-slate-100 mt-1">
              Scientifically Falsifiable Research Hypotheses
            </h2>
          </div>
          <div className="text-xs text-orange-400 font-mono bg-orange-500/10 px-3 py-1.5 rounded-lg border border-orange-500/30">
            PROPOSED HYPOTHESES — NOT ESTABLISHED FINDINGS
          </div>
        </div>

        <div className="pt-3 flex items-start gap-2.5 text-xs text-slate-300 bg-orange-500/5 p-3 rounded-lg border border-orange-500/20">
          <ShieldAlert className="w-4 h-4 text-orange-400 shrink-0 mt-0.5" />
          <div>
            <strong className="text-orange-300">Epistemic Constraint: </strong>
            These statements represent structured, testable propositions derived from identified evidence gaps and data trends. They must be validated through prospective empirical trials.
          </div>
        </div>
      </div>

      {/* Hypotheses Cards */}
      <div className="space-y-6">
        {investigation.hypotheses.map((item, idx) => (
          <div
            key={item.id}
            className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-5 hover:border-slate-700 transition-colors"
          >
            {/* Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-orange-500/20 border border-orange-500/40 text-orange-400 text-xs font-mono font-bold flex items-center justify-center">
                  H{idx + 1}
                </span>
                <span className="px-2.5 py-0.5 rounded font-mono text-[10px] bg-orange-950 text-orange-300 border border-orange-500/40 font-semibold tracking-wider">
                  {item.statusLabel}
                </span>
              </div>
              <span className="text-xs text-slate-400 font-mono">ID: {item.id}</span>
            </div>

            {/* Main Statement */}
            <div className="p-4 bg-slate-800/40 rounded-lg border border-slate-700/60">
              <span className="text-[10px] font-mono text-orange-400 uppercase tracking-wider block mb-1">
                FORMAL TESTABLE STATEMENT:
              </span>
              <p className="text-sm font-semibold text-slate-100 leading-relaxed">
                "{item.hypothesis}"
              </p>
            </div>

            {/* Grid of Attributes */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              {/* Scientific Rationale */}
              <div className="p-3.5 bg-slate-800/30 rounded-lg border border-slate-800 space-y-1">
                <span className="font-semibold text-slate-300 block text-[11px]">THEORETICAL RATIONALE:</span>
                <p className="text-slate-300 leading-relaxed">{item.rationale}</p>
              </div>

              {/* Expected Relationship */}
              <div className="p-3.5 bg-slate-800/30 rounded-lg border border-slate-800 space-y-1">
                <span className="font-semibold text-slate-300 block text-[11px]">EXPECTED RELATIONSHIP:</span>
                <p className="text-slate-300 leading-relaxed">{item.expectedRelationship}</p>
              </div>

              {/* Variables */}
              <div className="p-3.5 bg-slate-800/30 rounded-lg border border-slate-800 space-y-2">
                <span className="font-semibold text-slate-300 block text-[11px] flex items-center gap-1.5">
                  <Sliders className="w-3.5 h-3.5 text-cyan-400" /> Operational Variables
                </span>
                <div className="space-y-1.5 pl-1">
                  <div>
                    <span className="text-[10px] font-mono text-cyan-400 block">INDEPENDENT VARIABLE (X):</span>
                    <span className="text-slate-200">{item.independentVariable}</span>
                  </div>
                  <div>
                    <span className="text-[10px] font-mono text-emerald-400 block">DEPENDENT VARIABLE (Y):</span>
                    <span className="text-slate-200">{item.dependentVariable}</span>
                  </div>
                </div>
              </div>

              {/* Suggested Methodology */}
              <div className="p-3.5 bg-slate-800/30 rounded-lg border border-slate-800 space-y-1">
                <span className="font-semibold text-slate-300 block text-[11px] flex items-center gap-1.5">
                  <FlaskConical className="w-3.5 h-3.5 text-indigo-400" /> Suggested Empirical Testing Protocol
                </span>
                <p className="text-slate-300 leading-relaxed">{item.suggestedMethodology}</p>
              </div>
            </div>

            {/* Supporting Evidence and Limitations */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs pt-1">
              <div>
                <span className="text-[11px] font-semibold text-emerald-400 block mb-1">Supporting Foundations:</span>
                <ul className="space-y-1 text-slate-400">
                  {item.supportingEvidence.map((ev, i) => (
                    <li key={i} className="flex items-start gap-1.5">
                      <span className="text-emerald-500 font-bold">•</span>
                      <span>{ev}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <span className="text-[11px] font-semibold text-amber-400 block mb-1 flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3" /> Falsification & Known Limitations:
                </span>
                <ul className="space-y-1 text-slate-400">
                  {item.limitations.map((lim, i) => (
                    <li key={i} className="flex items-start gap-1.5">
                      <span className="text-amber-500 font-bold">•</span>
                      <span>{lim}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        ))}
      </div>

      {onNavigateToPaper && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 flex items-center justify-between">
          <div>
            <h4 className="text-sm font-semibold text-slate-100">Ready to Review Full Academic Manuscript?</h4>
            <p className="text-xs text-slate-400">View the structured 14-section mini research paper incorporating these hypotheses.</p>
          </div>
          <button
            onClick={onNavigateToPaper}
            className="py-2 px-4 bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs rounded-lg flex items-center gap-2 transition-colors"
          >
            <span>Review Mini Paper</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
};
