/**
 * ResearchPilotAI - Evidence Engine View
 * Central Evidence Layer displaying verified claims, literature citations, and evidence classifications.
 */

import React, { useState } from 'react';
import { ResearchInvestigation, EvidenceStatus } from '../../types/research';
import { EvidenceBadge } from '../common/EvidenceBadge';
import { ShieldCheck, BookOpen, ExternalLink, Filter, Search, Quote, CheckCircle2, AlertCircle } from 'lucide-react';

interface Props {
  investigation: ResearchInvestigation;
}

export const EvidenceEngineView: React.FC<Props> = ({ investigation }) => {
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filteredClaims = investigation.evidenceClaims.filter(claim => {
    const matchesStatus = selectedStatus === 'ALL' || claim.status === selectedStatus;
    const matchesSearch = claim.claim.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          claim.explanation.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* Evidence Engine Constitution Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
          <div>
            <h2 className="text-base font-semibold text-slate-100 flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
              Central Evidence Layer & Epistemic Traceability
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Every scientific claim produced by ResearchPilotAI carries an explicit epistemic status. Hypotheses are never presented as established facts.
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs text-slate-400 font-mono">
            <span>Verified Sources: {investigation.sources.length}</span>
            <span>·</span>
            <span>Claims Evaluated: {investigation.evidenceClaims.length}</span>
          </div>
        </div>

        {/* Classification Legend */}
        <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-5 gap-3 pt-4">
          <div className="p-2.5 rounded-lg bg-slate-800/40 border border-slate-700/50">
            <EvidenceBadge status="VERIFIED_SOURCE" size="sm" />
            <p className="text-[11px] text-slate-400 mt-1.5">Directly supported by retrieved peer-reviewed source.</p>
          </div>
          <div className="p-2.5 rounded-lg bg-slate-800/40 border border-slate-700/50">
            <EvidenceBadge status="DATA_DERIVED" size="sm" />
            <p className="text-[11px] text-slate-400 mt-1.5">Calculated from uploaded or retrieved dataset.</p>
          </div>
          <div className="p-2.5 rounded-lg bg-slate-800/40 border border-slate-700/50">
            <EvidenceBadge status="AI_INTERPRETATION" size="sm" />
            <p className="text-[11px] text-slate-400 mt-1.5">Reasonable synthesis or contextual inference.</p>
          </div>
          <div className="p-2.5 rounded-lg bg-slate-800/40 border border-slate-700/50">
            <EvidenceBadge status="HYPOTHESIS" size="sm" />
            <p className="text-[11px] text-slate-400 mt-1.5">Proposed idea requiring future experimental test.</p>
          </div>
          <div className="p-2.5 rounded-lg bg-slate-800/40 border border-slate-700/50">
            <EvidenceBadge status="INSUFFICIENT_EVIDENCE" size="sm" />
            <p className="text-[11px] text-slate-400 mt-1.5">Insufficient evidence to substantiate claim.</p>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-slate-900 border border-slate-800 rounded-xl p-3">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search claims or explanations..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-emerald-500"
          />
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
          {[
            { id: 'ALL', label: 'All Claims' },
            { id: 'VERIFIED_SOURCE', label: 'Verified' },
            { id: 'DATA_DERIVED', label: 'Data-Derived' },
            { id: 'AI_INTERPRETATION', label: 'AI Inference' },
            { id: 'HYPOTHESIS', label: 'Hypothesis' },
            { id: 'INSUFFICIENT_EVIDENCE', label: 'Insufficient' },
          ].map(f => (
            <button
              key={f.id}
              onClick={() => setSelectedStatus(f.id)}
              className={`px-2.5 py-1 text-xs rounded transition-colors whitespace-nowrap ${
                selectedStatus === f.id
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-medium'
                  : 'bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-700/60'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Claims List */}
      <div className="space-y-4">
        <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
          Evaluated Scientific Claims ({filteredClaims.length})
        </h3>

        <div className="grid grid-cols-1 gap-4">
          {filteredClaims.map((claim) => {
            const linkedSources = investigation.sources.filter(s => claim.sourceIds.includes(s.id));

            return (
              <div
                key={claim.id}
                className="bg-slate-900 border border-slate-800 rounded-xl p-5 hover:border-slate-700 transition-all space-y-3"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <EvidenceBadge status={claim.status} size="md" />
                  <span className="text-[11px] font-mono text-slate-400">
                    Confidence Tier: <strong className="text-slate-200">{claim.confidence}</strong>
                  </span>
                </div>

                <p className="text-sm font-medium text-slate-100 leading-relaxed">
                  "{claim.claim}"
                </p>

                <div className="p-3 bg-slate-800/50 rounded-lg text-xs text-slate-300 border border-slate-800">
                  <span className="font-semibold text-slate-400 block mb-1">EPISTEMIC RATIONALE:</span>
                  <p>{claim.explanation}</p>
                </div>

                {linkedSources.length > 0 && (
                  <div className="pt-2 border-t border-slate-800">
                    <span className="text-[11px] text-slate-400 block mb-1.5 font-medium">Traceable Literature Citations:</span>
                    <div className="space-y-1.5">
                      {linkedSources.map(s => (
                        <div key={s.id} className="flex items-center justify-between text-xs text-slate-300 bg-slate-800/30 p-2 rounded border border-slate-800">
                          <span className="font-medium text-emerald-300">
                            {s.authors[0]} et al. ({s.year}) — <span className="text-slate-300 font-normal">{s.title}</span>
                          </span>
                          {s.urlOrDoi && (
                            <a
                              href={s.urlOrDoi}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-cyan-400 hover:underline flex items-center gap-1 text-[11px] shrink-0 ml-3"
                            >
                              <span>View DOI</span>
                              <ExternalLink className="w-3 h-3" />
                            </a>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Verified Literature Sources Section */}
      <div className="space-y-4 pt-6">
        <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-emerald-400" />
          Retrieved Scientific Sources ({investigation.sources.length})
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {investigation.sources.map((src) => (
            <div
              key={src.id}
              className="bg-slate-900 border border-slate-800 rounded-xl p-5 flex flex-col justify-between space-y-4 hover:border-slate-700 transition-colors"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <EvidenceBadge status={src.evidenceStatus} size="sm" />
                  <span className="text-xs font-mono text-slate-400">{src.year}</span>
                </div>
                <h4 className="font-semibold text-sm text-slate-100 leading-snug line-clamp-2">
                  {src.title}
                </h4>
                <p className="text-xs text-slate-400 font-mono">
                  {src.authors.join(', ')}
                </p>
                <p className="text-xs text-emerald-400 italic">
                  {src.source}
                </p>
                <div className="pt-2 text-xs text-slate-300 border-t border-slate-800">
                  <strong className="text-slate-400 block text-[11px] mb-0.5">KEY FINDING:</strong>
                  <p className="text-[11px] leading-relaxed line-clamp-3">{src.keyFinding}</p>
                </div>
              </div>

              {src.urlOrDoi && (
                <a
                  href={src.urlOrDoi}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-cyan-300 font-medium text-xs rounded-lg flex items-center justify-center gap-1.5 transition-colors border border-slate-700/60"
                >
                  <span>Verify at Journal Source</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
